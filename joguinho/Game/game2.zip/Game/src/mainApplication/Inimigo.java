package mainApplication;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Inimigo extends Personagem {
	
	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] soco;
	private int imagemAtual;
	private boolean atacando;
	private int imagemAtualSoco;
	private int timer;
	private int tempoDoSoco;
	private int quantidadeDeFramesSoco;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	
	private int pausa;
	
	public Inimigo(int posX, int posY, int altura, int largura, int velocidade, int fimDaTelaEsquerda, int fimDaTelaDireita) {
		super(posX, posY, altura, largura, velocidade, fimDaTelaEsquerda, fimDaTelaDireita);
		//variaveis que necessitam inicializacao
		this.atacando = false;
		timer = 0;
		imagemAtual = 0;
		imagemAtualSoco = 0;
		tempoDoSoco = 5;
		
		pausa = 40;
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
	}
	
	public void criarAnimacoes() {
		
		correndo = carregarImagens("Data/Sprites/Jogador/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Jogador/Idle/adventurer-idle-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Jogador/Punch/adventurer-attack1-0", 3,"png");

	}
	
	
	public void atualizar() {
		if(atacando) {
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}
		
	}
		
	public void pintarInimigo(Graphics2D g) {
		
		if(!atacando) {
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else  {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g, soco, imagemAtualSoco);
		}
	}
	
	//inicia o ataque
	public void atacar() {
		if(!atacando) {
			atacando = true;
			imagemAtualSoco = 0;
			timer = 0;
		}
		
	}
	
	/*
	 * implementar aq algum tipo de verificacao de colisao para saber se o ataque atingiu algum inimigo
	 * cria um contador menor para a animacao do soco
	 * e verifica se tem inimigos na regiao prox
	 */
	public void ataca() {

		if(timer >= tempoDoSoco) {
			imagemAtualSoco++;
			//verifica se tem jogador
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
			}
			timer = 0;
		}
		timer++;
	}
	
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}

	//
	//
	public void atualizarSeguir(int posXAlvo) {
		seguirPosicoes(posXAlvo);
		if(atacando) {
			
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}	
	}
	/*
	 * decide qual direcao andar de acordo com uma posicao alvo
	 */
	public void seguirPosicoes(int posXAlvo) {
		if(getPosX() - posXAlvo < -60) {
			pausa=40;
			andar(1);
		}else if(getPosX() - posXAlvo > 60){
			pausa=40;
			andar(-1);
		}else if(getPosX() - posXAlvo > -60 && getPosX() - posXAlvo < 60) {
			if(pausa==40) {
				atacar();
				pausa=0;
			}
			else {
				andar(0);
				pausa++;
			}
		}
	}
	
}
