package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;

public class Overlay {

    private int altura = 10;
    private int largura = 10;

    public void pintarVida(Graphics2D g, int vida) {


        for(int i = 0; i < vida ; i++) {
            g.setColor(Color.red);
            g.fillRect(40+ (largura+1)*i,40,largura,altura);
        }
    }


}