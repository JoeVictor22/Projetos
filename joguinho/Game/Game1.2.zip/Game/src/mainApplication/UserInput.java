package mainApplication;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class UserInput implements KeyListener{

	private Jogador jogador;
	private Canvas jogo;
	
	private boolean andandoDireita;
	private boolean andandoEsquerda;
	private boolean atacando;
	
	private Janela janela;

	
	

	
	public UserInput(Canvas jogo , Janela janela) {
		this.jogador = jogo.getJogador();
		this.jogo = jogo;
		this.andandoDireita = false;
		this.andandoEsquerda = false;
		this.atacando = false;
		jogo.setPausado(false);
		
		this.janela = janela;
		
		
	}
	
	public void verificar() {
		//return this.jogador;
	}
	
	//implementacao de keyListener
	
	
	public void keyPressed(KeyEvent e) {
		
		//jogo rodando
		if(!jogo.isPausado()) {
			
			//esquerda
			if(e.getKeyCode() == KeyEvent.VK_A) {
				if(andandoDireita == true) {
					jogador.andar(0);
				//	inimigo.andar(0);
				}else {
					jogador.andar(-1);
					//inimigo.andar(-1);
				}
				andandoEsquerda = true;
							
			}
			
			//direita
			if(e.getKeyCode() == KeyEvent.VK_D) {
				if(andandoEsquerda == true) {
					jogador.andar(0);
					//inimigo.andar(0);
				}else {
					jogador.andar(1);
				//	inimigo.andar(1);
				}
				andandoDireita = true;
			}
			
			//saltar
			if(e.getKeyCode() == KeyEvent.VK_W && !jogador.isPulando() && !jogador.isAtacando()) {
				jogador.pular();
			}
			
			//bater
			if(e.getKeyCode() == KeyEvent.VK_F ) {
				if(!atacando) {
					jogador.setVida(jogador.getVida() - 1);
					jogador.atacar();
					//inimigo.atacar();
					atacando = true;
				}
			}
			
			//pausar
			if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				jogo.setPausado(true);
			}
			
			//botao de testes
			if(e.getKeyCode() == KeyEvent.VK_E) {
				//jogador.setPontuacao(jogador.getPontuacao() + 1);
				janela.entradaRanking();
			}
			if(e.getKeyCode() == KeyEvent.VK_Q) {
				//jogador.setPontuacao(jogador.getPontuacao() - 1);
		
		
			}
			
		//jogo pausado	
		}else {	
			if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				jogo.setPausado(false);
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		
		if(e.getKeyCode() == KeyEvent.VK_A) {
			if(andandoDireita == true) {
				jogador.andar(1);
				//inimigo.andar(1);
				
			}else {
				jogador.andar(0);
				//inimigo.andar(0);
			}
			andandoEsquerda = false;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_D) {
			if(andandoEsquerda == true) {
				jogador.andar(-1);
				//inimigo.andar(-1);
			}else {
				jogador.andar(0);
				//inimigo.andar(0);
			}
			andandoDireita = false;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_F) {
			atacando = false;
		}
	}
	
	public void keyTyped(KeyEvent e) {
		
	}
	
}
