package mainApplication;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class Ranking {

	private int h;
	private int w;
	
	BufferedImage fundo;
	
	public Ranking(int h, int w){
		this.h = h;
		this.w = w;
	
		
		try {
			fundo = ImageIO.read(new File("Data/Extra/rankingFundo.png"));
		}catch(IOException e) {
			System.out.println("Nao carregou plano de fundo do ranking!");
			 Logger.getLogger(Ranking.class.getName()).log(Level.SEVERE, null, e);
		}
		fundo = resize(fundo,h,w);
		
	}
	
	public void loop() {
		/*
		pintarFundo();
		if(verificarPontuacao()) {
			digiteNome();
			salvarArquivo();
		}
		pintarRanking();
		esperarEntrada();
		*/
	}
	
	
	
	public void pintarFundo(Graphics2D g) {
		g.drawImage(fundo,null,0,0);
		
	}
	
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
}
