package mainApplication;
import javax.swing.JFrame;

public class Janela {

	private JFrame janela;
	private Canvas jogo;
	
	private UserInput entrada;
	private UserInputRanking entradaRanking;
	
	private int altura;
	private int largura; 
	
	public Janela(int altura, int largura) {
		this.altura = altura;
		this.largura = largura;
	}	
		
	public void create() {
		//definindo Jframe que usaremos
		janela = new JFrame("Nome do Jogo");
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setSize(largura, altura);
		janela.setResizable(false);

		//instanciando jogo
		jogo = new Canvas(largura,altura);
		//adicionando o jogo component e seu keyListener ao JFrame criado
		janela.add(jogo);
		
		entrada = new UserInput(jogo, this);
		entradaRanking = new UserInputRanking(jogo,this);
		
		janela.addKeyListener(entrada);
		janela.setVisible(true);	
	}

	public void entradaRanking() {
		janela.removeKeyListener(entrada);
		janela.addKeyListener(entradaRanking);
	}
		
	public void entradaJogo() {
		janela.removeKeyListener(entradaRanking);
		janela.addKeyListener(entrada);
	}
	
}
