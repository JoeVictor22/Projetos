package mainApplication;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Inimigo extends Personagem {
	
	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] soco;
	private int imagemAtual;
	private boolean atacando;
	private int imagemAtualSoco;
	private int timer;
	private int tempoDoSoco;
	private int quantidadeDeFramesSoco;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	
	public Inimigo(int posX, int posY, int altura, int largura, int velocidade, int fimDaTelaEsquerda, int fimDaTelaDireita, int vida, int dano, int velocidadeSoco) {
		super(posX, posY, altura, largura, velocidade, fimDaTelaEsquerda, fimDaTelaDireita, vida, dano, velocidadeSoco);
		//variaveis que necessitam inicializacao
		this.atacando = false;
		timer = 0;
		imagemAtual = 0;
		imagemAtualSoco = 0;
		tempoDoSoco = 5;
		
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
	}
	
	public void criarAnimacoes() {
		
		correndo = carregarImagens("Data/Sprites/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Idle/adventurer-idle-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Punch/adventurer-attack1-0", 3,"png");

	}
	
	
	public void atualizar() {
		if(atacando) {
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}
		
	}
	public void atualizarSeguir(int posXAlvo) {
		seguirPosicoes(posXAlvo);
		if(atacando) {
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}	
	}
	
	
	public void pintarInimigo(Graphics2D g) {
		
		if(!atacando) {
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else  {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g, soco, imagemAtualSoco);
		}
	}
	
	//inicia o ataque

	
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}

	
	/*
	 * decide qual direcao andar de acordo com uma posicao alvo
	 */
	public void seguirPosicoes(int posXAlvo) {
		if(getPosX() < posXAlvo - getLargura()/3) {
			//setPosX(getPosX() + getVelocidade());
			andar(1);
		}else if(getPosX() > posXAlvo + getLargura()/3){
			andar(-1);
		}else {
			andar(0);
		}
		
	}

	public BufferedImage[] getCorrendo() {
		return correndo;
	}

	public void setCorrendo(BufferedImage[] correndo) {
		this.correndo = correndo;
	}

	public BufferedImage[] getParado() {
		return parado;
	}

	public void setParado(BufferedImage[] parado) {
		this.parado = parado;
	}

	public BufferedImage[] getSoco() {
		return soco;
	}

	public void setSoco(BufferedImage[] soco) {
		this.soco = soco;
	}

	public int getImagemAtual() {
		return imagemAtual;
	}

	public void setImagemAtual(int imagemAtual) {
		this.imagemAtual = imagemAtual;
	}

	public boolean isAtacando() {
		return atacando;
	}

	public void setAtacando(boolean atacando) {
		this.atacando = atacando;
	}

	public int getImagemAtualSoco() {
		return imagemAtualSoco;
	}

	public void setImagemAtualSoco(int imagemAtualSoco) {
		this.imagemAtualSoco = imagemAtualSoco;
	}

	public int getTimer() {
		return timer;
	}

	public void setTimer(int timer) {
		this.timer = timer;
	}

	public int getTempoDoSoco() {
		return tempoDoSoco;
	}

	public void setTempoDoSoco(int tempoDoSoco) {
		this.tempoDoSoco = tempoDoSoco;
	}

	public int getQuantidadeDeFramesSoco() {
		return quantidadeDeFramesSoco;
	}

	public void setQuantidadeDeFramesSoco(int quantidadeDeFramesSoco) {
		this.quantidadeDeFramesSoco = quantidadeDeFramesSoco;
	}

	public int getVelocidadeDasAnimacoes() {
		return velocidadeDasAnimacoes;
	}

	public void setVelocidadeDasAnimacoes(int velocidadeDasAnimacoes) {
		this.velocidadeDasAnimacoes = velocidadeDasAnimacoes;
	}

	public int getQuantidadeDeFrames() {
		return quantidadeDeFrames;
	}

	public void setQuantidadeDeFrames(int quantidadeDeFrames) {
		this.quantidadeDeFrames = quantidadeDeFrames;
	}
	
	
	
}
