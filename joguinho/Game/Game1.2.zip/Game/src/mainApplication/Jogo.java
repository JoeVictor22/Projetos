package mainApplication;

public class Jogo {

	
	
	public static void main(String[] args) {
	
		Janela janela = new Janela(640, 1280);
		boolean playAgain = true;
		
		while(playAgain) {
			janela.create();
			playAgain = false;
		}
		
		
	}
	
}
