package mainApplication;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

/*
 * Classe abstrata para servir de base na criacao do jogador e dos inimigos
 */

abstract public class Personagem {
	
	/*
	 * Atributos fundamentais que cada personagem devera ter
	 * Adcionar demais atributos na classe herdeira
	 */
	
	// Atributos relativos a localizacao
	private int posX;
	private int posY;
	
	// Atributos relativos as dimensoes
	private int largura;
	private int altura;
	
	private int vida;
	private int dano;
	// Atributos para controle de movimento
	private int direcao;
	private int ultimaDirecao;
	private int velocidade;
	private int fimDaTelaEsquerda;
	private int fimDaTelaDireita;
	
	// Atributos combate
	private boolean atacando;
	private int imagemAtualSoco;
	private int velocidadeSoco;
	private int quantidadeDeFramesSoco;
	
	// Atributos relacionados a animacoes devem ser criados nas classes herdeiras
	//private BufferedImage[] correndo;
	//private BufferedImage[] parado;
	//private BufferedImage[] pulando;
	//private int imagemAtual;
	
	/* Constructor com varios atributos para facilitar o reuso desse trecho
	 * 
	 */
	
	public Personagem(int posX, int posY, int altura, int largura,int velocidade, int fimDaTelaEsquerda, int fimDaTelaDireita, int vida, int dano, int velocidadeSoco) {
		
		this.posX = posX;
		this.posY = posY;
		
		this.altura = altura;
		this.largura = largura;
		
		this.velocidade = velocidade;
		this.direcao = 0;
		this.ultimaDirecao = 1;
		
		this.fimDaTelaDireita = fimDaTelaDireita;
		this.fimDaTelaEsquerda = fimDaTelaEsquerda;
		
		this.vida = vida;
		this.dano = dano;
		
		this.imagemAtualSoco = 0;
		this.atacando = false;
		this.quantidadeDeFramesSoco = 3;
		this.velocidadeSoco = velocidadeSoco;
		/*
		 * Instanciacao das animacoes
		 */
		criarAnimacoes();
		
	}
	
	
	//metodos abstratos	
	// Atualizar movimentos e variaveis de controle
	abstract public void atualizar();
	
	/*
	 * Utilizar esse metodo para fazer o carregamento de todas as animacoes necessarias no personagem
	 * EX :
	 * 		correndo = carregarImagens("enderecoBonitinho", 10);
	 *		parado = carregarImagens("enderecoBonitinho", 10);
	 *		pulando = carregarImagens("enderecoBonitinho", 10);
	 */
	abstract public void criarAnimacoes();
	
	
	
	
	/* metodo para pintar animacao
	 * enviar component de pintura vindo do canvas, e a animacao a ser utilizada
	 * o indice da animacao nesse metodo eh fixo
	 * ver documentacao do metodo drawImage herdado de java.awt.Graphics e java.awt.Graphics2D
	 */
	public void pintar(Graphics2D g, BufferedImage[] animacao, int imagemAtual) {
		if(ultimaDirecao == 1){      
	        g.drawImage(
	             animacao[imagemAtual],
	             posX,posY,
	             posX + largura, posY + altura,
	             0, 0,
	             animacao[imagemAtual].getWidth(), animacao[imagemAtual].getHeight(),
	             null);
	    }else if(ultimaDirecao == -1){
	            g.drawImage(
	            	animacao[imagemAtual],
	                posX,posY,
	                posX + largura, posY + altura,
	                animacao[imagemAtual].getWidth(),0,
	                0, animacao[imagemAtual].getHeight(),
	            null);
	    }
	}
	
	
	
	/* metodo para carregar imagens em um vetor
	 * enviar endereco, e quantidade de imagens e o tipo de extensao sem o ponto (.)
	 * o endereco das imagens devem ser iguais e enumerados no final de 1 ao size
	 * 
	 */
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 1; i <= size; i++) {	
			try {
				imagem[i-1] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				Logger.getLogger(Personagem.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
		
	}
	
	/*
	 * atualizacao da movimentacao lateral
	 */
	public void anda(){
		if(direcao == 1) {
			if((posX < fimDaTelaDireita)) {
				posX += velocidade;
			}
			
		}else if(direcao == -1){
			if((posX > fimDaTelaEsquerda)) {
				posX -= velocidade;
			}
		}
	}
	
	/*
	 * define a direcao de observacao
	 */
	public void andar(int direcao) {
		if(direcao != 0) {
			this.direcao = direcao;
			this.ultimaDirecao = direcao;
		}else {
			this.direcao = direcao;
		}
	}
	
	/*
	 * 
	 */
	//inicia o ataque
	public void atacar() {
		if(!atacando) {
			this.atacando = true;
			this.imagemAtualSoco = 0;
			setTimer(0);
		}
		
	}
	
	/*
	 * implementar aq algum tipo de verificacao de colisao para saber se o ataque atingiu algum inimigo
	 * cria um contador menor para a animacao do soco
	 * e verifica se tem inimigos na regiao prox
	 */
	public void ataca() {

		if(getTimer() >= velocidadeSoco) {
			imagemAtualSoco++;
			//verifica se tem inimigo
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
			}
			setTimer(0);
		}
		setTimer(getTimer()+1);
	}
	
	
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
			
		    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
		    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
	
		    Graphics2D g2d = novaImagem.createGraphics();
		    g2d.drawImage(temp, 0, 0, null);
		    g2d.dispose();
	
		    return novaImagem;
	}  
	

	abstract public int getTimer();
	abstract public void setTimer(int timer);
	/*
	
	
	
	
	
	/*
	 * metodos para alterar posicao caso necessario
	 */
	public void somarPosY(int soma){
		this.posY += soma;
		
	}
	public void somarPosX(int soma) {
		this.posX += soma;
		
	}
	
	/*
	 * Metodos de acesso
	 */
	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public int getLargura() {
		return largura;
	}

	public void setLargura(int largura) {
		this.largura = largura;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getDirecao() {
		return direcao;
	}

	public void setDirecao(int direcao) {
		this.direcao = direcao;
	}

	public int getUltimaDirecao() {
		return ultimaDirecao;
	}

	public void setUltimaDirecao(int ultimaDirecao) {
		this.ultimaDirecao = ultimaDirecao;
	}

	public int getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}


	public int getFimDaTelaEsquerda() {
		return fimDaTelaEsquerda;
	}


	public void setFimDaTelaEsquerda(int fimDaTelaEsquerda) {
		this.fimDaTelaEsquerda = fimDaTelaEsquerda;
	}


	public int getFimDaTelaDireita() {
		return fimDaTelaDireita;
	}


	public void setFimDaTelaDireita(int fimDaTelaDireita) {
		this.fimDaTelaDireita = fimDaTelaDireita;
	}


	public boolean isAtacando() {
		return atacando;
	}


	public void setAtacando(boolean atacando) {
		this.atacando = atacando;
	}


	public int getImagemAtualSoco() {
		return imagemAtualSoco;
	}


	public void setImagemAtualSoco(int imagemAtualSoco) {
		this.imagemAtualSoco = imagemAtualSoco;
	}


	public int getTempoDoSoco() {
		return velocidadeSoco;
	}


	public void setTempoDoSoco(int tempoDoSoco) {
		this.velocidadeSoco = tempoDoSoco;
	}


	public int getQuantidadeDeFramesSoco() {
		return quantidadeDeFramesSoco;
	}


	public void setQuantidadeDeFramesSoco(int quantidadeDeFramesSoco) {
		this.quantidadeDeFramesSoco = quantidadeDeFramesSoco;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public int getDano() {
		return dano;
	}
	public void setDano(int dano) {
		this.dano = dano;
	}
	
}
