package mainApplication;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Jogador extends Personagem{

	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] pulo;
	BufferedImage[] soco;
	private int imagemAtual;
	private int imagemAtualSoco;
	
	private int timer;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	private int quantidadeDeFramesSoco;
	private int tempoDoSoco;
	
	/*
	 * Variaveis de controle
	 */
	private boolean atacando;
	private boolean pulando;
	private int velocidadeSalto;
	public int alturaDoPulo;
	private int posYSalto;
	private boolean subir;
	
	public Jogador(int posX, int posY, int altura, int largura,int velocidade, int fimDaTelaEsquerda, int fimDaTelaDireita) {
		super(posX, posY, altura, largura, velocidade, fimDaTelaEsquerda, fimDaTelaDireita);
		//variaveis que necessitam inicializacao
		this.pulando = false;
		this.atacando = false;
		this.subir = false;
		timer = 0;
		imagemAtual = 0;
		imagemAtualSoco = 0;
		tempoDoSoco = 5;
		
		
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
	
		velocidadeSalto = 8;
		//alturaDoPulo deve ser multiplo da velocidadeSalto
		alturaDoPulo =  125;
	}
	
	/*
	 * carrega animacoes a serem utilizadas
	 */
	public void criarAnimacoes() {
		correndo = carregarImagens("Data/Sprites/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Idle/adventurer-idle-0", 6, "png");
		pulo = carregarImagens("Data/Sprites/Jump/adventurer-jump-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Punch/adventurer-attack1-0", 3,"png");
		
		
	}
	
	//controle de posicoes e de frames
	public void atualizar() {
		/*
		 * ataca() = atualiza a imagemAtual de atacar e realiza ataque
		 * atualizarContadorDeImagem() = atualiza imagemAtual na quantidade de frames padrao definida pela gente
		 * anda() = atualiza a locomocao no eixo X do personagem
		 * pula() = realiza salto e atualiza imagemAtual de acordo com o salto
		 */
		if(pulando == false) {
			if(atacando == true) {
				ataca();
			}else{
				atualizarContadorDeImagem();	
				anda();
			}
		}else {
			if(atacando == true) {
				ataca();
				pula(posYSalto);
				anda();
			}else {
				pula(posYSalto);
				anda();
			}
			
		}
	}
	
	/*
	 * o tratamento quanto a direcao � feito na classe personagem
	 * nesse metodo so eh definido qual animacao sera pintar
	 */
	public void pintarJogador(Graphics2D g) {
		//se pulando
		if(pulando == true) {
			if(atacando == false) {
				pintar(g, pulo, imagemAtual);
			}else {
				pintar(g,soco,imagemAtualSoco);
				/*
				 * alguma animacao dele batendo no ar
				 * enviar imagemAtualSoco
				 */
			}
				
		}else if(atacando == false){
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g,soco,imagemAtualSoco);
		}
		
	}
	
	
	//metodo definido na classe pai
	/*
	 * define a direcao de observacao
	 */
	/*
	public void andar(int direcao) {
		
		if(direcao != 0) {
			setDirecao(direcao);
			setUltimaDirecao(direcao);
		}else {
			setDirecao(direcao);
		}
	}
	*/
	
	/*
	 * inicia o pulo
	 */
	public void pular() {
		//imagem pulando
		this.imagemAtual = 2;
		this.posYSalto = getPosY();
		this.pulando = true;
		this.subir = true;
	}
	
	
	//atualiza imagemAtual com base em um timer
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}
	
	public void pula(int posY) {
		if(getPosY() > (posY - alturaDoPulo) && subir == true) {
			somarPosY(-velocidadeSalto);
		}else if(getPosY()  < posY) {
			if(subir == true) {
				//imagem dele caindo
				imagemAtual = 4;
			}
			subir = false;
			somarPosY(velocidadeSalto );
		}else {
			pulando = false;
			imagemAtual = 0;
		}
		
	}
	

	//inicia o ataque
	public void atacar() {
		if(!atacando) {
			this.atacando = true;
			this.imagemAtualSoco = 0;
			timer = 0;
		}
		
	}
	
	/*
	 * implementar aq algum tipo de verificacao de colisao para saber se o ataque atingiu algum inimigo
	 * cria um contador menor para a animacao do soco
	 * e verifica se tem inimigos na regiao prox
	 */
	public void ataca() {

		if(timer >= tempoDoSoco) {
			imagemAtualSoco++;
			//verifica se tem inimigo
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
			}
			timer = 0;
		}
		timer++;
	}
	
	/*
	 * Metodos de acesso
	 */
	public int getImagemAtual() {
		return imagemAtual;
	}

	public void setImagemAtual(int imagemAtual) {
		this.imagemAtual = imagemAtual;
	}

	public int getQuantidadeDeFrames() {
		return quantidadeDeFrames;
	}

	public void setQuantidadeDeFrames(int quantidadeDeFrames) {
		this.quantidadeDeFrames = quantidadeDeFrames;
	}

	public boolean isPulando() {
		return pulando;
	}

	public void setPulando(boolean pulando) {
		this.pulando = pulando;
	}

	public int getTamanhoDeUmSalto() {
		return velocidadeSalto;
	}

	public void setTamanhoDeUmSalto(int tamanhoDeUmSalto) {
		this.velocidadeSalto = tamanhoDeUmSalto;
	}

	
}
