package mainApplication;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Jogador extends Personagem{

	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] pulo;
	BufferedImage[] soco;
	private int imagemAtual;
	
	private int timer;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	private int quantidadeDeFramesSoco;
	
	/*
	 * Variaveis de controle
	 */
	private boolean pulando;
	private int velocidadeSalto;
	public int alturaDoPulo;
	private int posYSalto;
	private boolean subir;
	
	private long pontuacao;
	
	public Jogador(int posX, int posY, int altura, int largura,int velocidade, int fimDaTelaEsquerda, int fimDaTelaDireita, int vida, int dano, int velocidadeSoco) {
		super(posX, posY, altura, largura, velocidade, fimDaTelaEsquerda, fimDaTelaDireita, vida, dano, velocidadeSoco);
		//variaveis que necessitam inicializacao
		this.pulando = false;
		this.subir = false;
		timer = 0;
		imagemAtual = 0;
		
		
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
	
		velocidadeSalto = 8;
		//alturaDoPulo deve ser multiplo da velocidadeSalto
		alturaDoPulo =  125;
		
		pontuacao = 0;
	}
	
	/*
	 * carrega animacoes a serem utilizadas
	 */
	public void criarAnimacoes() {
		correndo = carregarImagens("Data/Sprites/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Idle/adventurer-idle-0", 6, "png");
		pulo = carregarImagens("Data/Sprites/Jump/adventurer-jump-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Punch/adventurer-attack1-0", 3,"png");
		
		
	}
	
	//controle de posicoes e de frames
	public void atualizar() {
		/*
		 * ataca() = atualiza a imagemAtual de atacar e realiza ataque
		 * atualizarContadorDeImagem() = atualiza imagemAtual na quantidade de frames padrao definida pela gente
		 * anda() = atualiza a locomocao no eixo X do personagem
		 * pula() = realiza salto e atualiza imagemAtual de acordo com o salto
		 */
		if(pulando == true) {
			if(isAtacando() == false) {
				pula(posYSalto);
				anda();
			}else{
				pula(posYSalto);
				ataca();
				anda();
			}
		}else if(isAtacando() == false){
			anda();
			atualizarImagem();
		}else {
			ataca();
		}
			
			//qnd andar
			//atualizarContadorDeImagem();
		}
	
	
	/*
	 * o tratamento quanto a direcao � feito na classe personagem
	 * nesse metodo so eh definido qual animacao sera pintar
	 */
	public void pintarJogador(Graphics2D g) {
		//se pulando
		if(pulando == true) {
			if(isAtacando() == false) {
				pintar(g, pulo, imagemAtual);
			}else {
				pintar(g,soco,getImagemAtualSoco());
				/*
				 * alguma animacao dele batendo no ar
				 * enviar imagemAtualSoco
				 */
			}
				
		}else if(isAtacando() == false){
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g,soco,getImagemAtualSoco());
		}
		
	}
	

	/*
	 * inicia o pulo
	 */
	public void pular() {
		//imagem pulando
		this.imagemAtual = 2;
		this.posYSalto = getPosY();
		this.pulando = true;
		this.subir = true;
	}
	
	
	//atualiza imagemAtual com base em um timer
	public void atualizarImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}
	
	public void pula(int posY) {
		if(getPosY() > (posY - alturaDoPulo) && subir == true) {
			somarPosY(-velocidadeSalto);
		}else if(getPosY()  < posY) {
			if(subir == true) {
				//imagem dele caindo
				imagemAtual = 4;
			}
			subir = false;
			somarPosY(velocidadeSalto );
		}else {
			pulando = false;
			imagemAtual = 0;
		}
		
	}
	


	// Metodos de acesso
	public int getImagemAtual() {
		return imagemAtual;
	}

	public void setImagemAtual(int imagemAtual) {
		this.imagemAtual = imagemAtual;
	}

	public int getQuantidadeDeFrames() {
		return quantidadeDeFrames;
	}

	public void setQuantidadeDeFrames(int quantidadeDeFrames) {
		this.quantidadeDeFrames = quantidadeDeFrames;
	}

	public boolean isPulando() {
		return pulando;
	}

	public void setPulando(boolean pulando) {
		this.pulando = pulando;
	}

	public int getTamanhoDeUmSalto() {
		return velocidadeSalto;
	}

	public void setTamanhoDeUmSalto(int tamanhoDeUmSalto) {
		this.velocidadeSalto = tamanhoDeUmSalto;
	}

	public BufferedImage[] getCorrendo() {
		return correndo;
	}

	public void setCorrendo(BufferedImage[] correndo) {
		this.correndo = correndo;
	}

	public BufferedImage[] getParado() {
		return parado;
	}

	public void setParado(BufferedImage[] parado) {
		this.parado = parado;
	}

	public BufferedImage[] getPulo() {
		return pulo;
	}

	public void setPulo(BufferedImage[] pulo) {
		this.pulo = pulo;
	}

	public BufferedImage[] getSoco() {
		return soco;
	}

	public void setSoco(BufferedImage[] soco) {
		this.soco = soco;
	}

	public int getTimer() {
		return timer;
	}

	public void setTimer(int timer) {
		this.timer = timer;
	}

	public int getVelocidadeDasAnimacoes() {
		return velocidadeDasAnimacoes;
	}

	public void setVelocidadeDasAnimacoes(int velocidadeDasAnimacoes) {
		this.velocidadeDasAnimacoes = velocidadeDasAnimacoes;
	}

	public int getQuantidadeDeFramesSoco() {
		return quantidadeDeFramesSoco;
	}

	public void setQuantidadeDeFramesSoco(int quantidadeDeFramesSoco) {
		this.quantidadeDeFramesSoco = quantidadeDeFramesSoco;
	}

	public int getVelocidadeSalto() {
		return velocidadeSalto;
	}

	public void setVelocidadeSalto(int velocidadeSalto) {
		this.velocidadeSalto = velocidadeSalto;
	}

	public int getAlturaDoPulo() {
		return alturaDoPulo;
	}

	public void setAlturaDoPulo(int alturaDoPulo) {
		this.alturaDoPulo = alturaDoPulo;
	}

	public int getPosYSalto() {
		return posYSalto;
	}

	public void setPosYSalto(int posYSalto) {
		this.posYSalto = posYSalto;
	}

	public boolean isSubir() {
		return subir;
	}

	public void setSubir(boolean subir) {
		this.subir = subir;
	}
	public long getPontuacao() {
		return pontuacao;
	}
	public void setPontuacao(long pontuacao) {
		this.pontuacao = pontuacao;
	}
	
}
