package mainApplication;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Canvas extends JPanel implements Runnable, KeyListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6244965887359695579L;
	
	private int h,w;
	
	private BufferedImage[] cenario = new BufferedImage[3];
	private Jogador jogador;
	private Overlay overlay;
	private Inimigo[] inimigo;
	private int larguraDoPersonagem;
	private int alturaDoPersonagem;
	private int quantidadeDeInimigos;
	
	/*
	 * atributos para resolver problemas com entrada do teclado
	 */
	private boolean andandoDireita;
	private boolean andandoEsquerda;
	private boolean atacando;
	
	
	Thread gameLoop = new Thread(this);
	

	//= new BufferedImage(null, null, false , null);
	//cenario = ImageIO.read(new File("asd"));
	
	//constructor
	public Canvas(int h, int w) {
		
		andandoDireita = false;
		andandoEsquerda = false;
		this.atacando = false;
		larguraDoPersonagem = 150;
		alturaDoPersonagem = 100;
		jogador = new Jogador( 0, 500, alturaDoPersonagem, larguraDoPersonagem, 6, 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
		quantidadeDeInimigos = 10;
		inimigo = new Inimigo[quantidadeDeInimigos];
		//cria vetor de inimigos
		for(int i = 0; i < quantidadeDeInimigos; i++) {
			Random random = new Random();
			inimigo[i] = new Inimigo( random.nextInt(h), 500, alturaDoPersonagem, larguraDoPersonagem, 1+random.nextInt(4), 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
		}
		
		overlay = new Overlay();
		
		this.h = h;
		this.w = w;
		//carrega cenario
		for(int i = 0; i < 3;i++) {
			try {
				cenario[i] = ImageIO.read(new File("Data/Scenes/game"+ i + ".png"));
				 cenario[i] = resize(cenario[i],h, w);
			}catch(IOException e) {
				System.out.println("nao carregou background");
	            Logger.getLogger(Canvas.class.getName()).log(Level.SEVERE, null, e);
				
			}
			
		}
		
		
		
		
		
		gameLoop.start();
		
		
	}
	
	//instrucoes
	public void run() {
		long timer = System.currentTimeMillis();
		int frames = 0;
		
		while(true) {
			
		
			atualiza();
			repaint();
			dorme();	
	
		
			/*
			 * contador de frames
			 */
			frames++;			
			if(System.currentTimeMillis() - timer > 1000) {
				timer+= 1000;
				System.out.println("frames = " + frames);
				frames = 0;
			}
		}	
	}
	
	//instrucao para atualizar componentes do jogo
	public void atualiza() {
		jogador.atualizar();
		//atualiza vetor de inimigos
		for(int i = 0; i < quantidadeDeInimigos; i++) {
			inimigo[i].atualizarSeguir(jogador.getPosX());
		}
		
	}
	//instrucao para gerar delay no thread
	public void dorme() {
		try {
			Thread.sleep(16);
		} catch(InterruptedException e) {
			Logger.getLogger(Canvas.class.getName()).log(Level.SEVERE, null, e);
		}
	}
	
	//pintura dos componentes(repaint)
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D) g.create();
		
		//pinta as imagens de background
		g2d.drawImage(cenario[1], null, 0,0 );
		g2d.drawImage(cenario[0], null, 0, 0);
		g2d.drawImage(cenario[2], null, 0, 0);
		
		
		//pinta o jogador
		jogador.pintarJogador(g2d);
		//pinta vetor de inimigos
		for(int i = 0 ; i < quantidadeDeInimigos; i++) {
			inimigo[i].pintarInimigo(g2d);
		}
		overlay.pintarVida(g2d, jogador.getVida());
		overlay.pintarScore(g2d, jogador.getPontuacao());
		
		
		/*
		 * teste tamanho do salto
		 * altura do retangulo deve ser a posY menos a altura do salto
		*/
		
	
		/*
		g2d.setColor(Color.black);
	    g2d.fillRect(50,375,100,100);
	    */
	}
	
	
	
	//implementacao de keyListener
	
	public void keyPressed(KeyEvent e) {
		
		//esquerda
		if(e.getKeyCode() == KeyEvent.VK_A) {
			if(andandoDireita == true) {
				jogador.andar(0);
			//	inimigo.andar(0);
			}else {
				jogador.andar(-1);
				//inimigo.andar(-1);
			}
			andandoEsquerda = true;
						
		}
		
		//direita
		if(e.getKeyCode() == KeyEvent.VK_D) {
			if(andandoEsquerda == true) {
				jogador.andar(0);
				//inimigo.andar(0);
			}else {
				jogador.andar(1);
			//	inimigo.andar(1);
			}
			andandoDireita = true;
		}
		
		//saltar
		if(e.getKeyCode() == KeyEvent.VK_W && !jogador.isPulando() && !jogador.isAtacando()) {
			jogador.pular();
		}
		
		//bater
		if(e.getKeyCode() == KeyEvent.VK_F ) {
			if(!atacando) {
				jogador.setVida(jogador.getVida() - 1);
				jogador.atacar();
				//inimigo.atacar();
				atacando = true;
			}
		}
		
		//botao de testes
		if(e.getKeyCode() == KeyEvent.VK_E) {
			jogador.setPontuacao(jogador.getPontuacao() + 100000);
			//pausado = true;
			gameLoop.suspend();
		}
		if(e.getKeyCode() == KeyEvent.VK_Q) {
			jogador.setPontuacao(jogador.getPontuacao() - 1000);
			//pausado = false;
			gameLoop.resume();
		}
		
	}
	
	public void keyReleased(KeyEvent e) {
		
		if(e.getKeyCode() == KeyEvent.VK_A) {
			if(andandoDireita == true) {
				jogador.andar(1);
				//inimigo.andar(1);
				
			}else {
				jogador.andar(0);
				//inimigo.andar(0);
			}
			andandoEsquerda = false;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_D) {
			if(andandoEsquerda == true) {
				jogador.andar(-1);
				//inimigo.andar(-1);
			}else {
				jogador.andar(0);
				//inimigo.andar(0);
			}
			andandoDireita = false;
		}
		
		if(e.getKeyCode() == KeyEvent.VK_F) {
			atacando = false;
		}
	}
	
	public void keyTyped(KeyEvent e) {
		
	}
	
	/*
	 * estudar esse lixo
	 * Metodo para redimensionar uma bufferedImage
	 */
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
}
