package mainApplication;

public class Jogo {

	
	

	
	public static void main(String[] args) {
	
		int h = 640;
		int w = 1280;
		Janela janela = new Janela(h, w);
	
		
		
		boolean playAgain = true;

		while(playAgain) {
			janela.create();
			
			
			playAgain = false;
		}
		
		
	}
	
}
