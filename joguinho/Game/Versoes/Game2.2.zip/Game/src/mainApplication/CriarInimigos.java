package mainApplication;

import java.util.Random;

public class CriarInimigos extends Thread {

	private Canvas jogo;
	
	
	public CriarInimigos(Canvas jogo ) {
		this.jogo = jogo;
		

	}
	
	public void run() {
		jogo.setInimigo(criarInimigos(50));
	
		
		
	}
	
	public Inimigo[] criarInimigos(int quantidadeDeInimigos) {
		
		int alturaDoPersonagem = 100;
		int larguraDoPersonagem = 150;
		int h = 1280;
		
		Random random = new Random();
		
		
		Inimigo[] inimigo = new Inimigo[quantidadeDeInimigos];
		for(int i = 0; i < quantidadeDeInimigos/2; i++) {
			
			inimigo[i] = new Inimigo( h + 1000 + random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 1 + 5*random.nextFloat(), 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
			
		}
		for(int i = quantidadeDeInimigos/2; i < quantidadeDeInimigos; i++) {
	
			inimigo[i] = new Inimigo( 0 - 1000 - random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 1 + 5*random.nextFloat(), 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
			
		}
		return inimigo;
	}
}
