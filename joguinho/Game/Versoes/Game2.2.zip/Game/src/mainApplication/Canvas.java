package mainApplication;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Canvas extends JPanel implements Runnable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6244965887359695579L;
	
	private int h,w;
	
	private BufferedImage[] cenario = new BufferedImage[3];
	private Jogador jogador;
	private Overlay overlay;
	private Inimigo[] inimigo;
	private UserInput entrada;
	private int larguraDoPersonagem;
	private int alturaDoPersonagem;
	
	private boolean pausado;
	private boolean jogando;
	
	private Ranking ranking;
	private Janela janela;
	
	private int rodada;
	
	
	/*
	 * atributos para resolver problemas com entrada do teclado
	 */
	
	
	Thread gameLoop = new Thread(this);
	

	//= new BufferedImage(null, null, false , null);
	//cenario = ImageIO.read(new File("asd"));
	
	//constructor
	public Canvas(int h, int w, Janela janela) {
		
		larguraDoPersonagem = 150;
		alturaDoPersonagem = 100;
		pausado = false;
		jogando = false;
		
		rodada = 0;
		
		this.janela = janela;
		
		ranking = new Ranking(janela);
		overlay = new Overlay(h,w);
		
		this.h = h;
		this.w = w;
		//carrega cenario
		for(int i = 0; i < 3;i++) {
			try {
				cenario[i] = ImageIO.read(new File("Data/Scenes/game"+ i + ".png"));
				 cenario[i] = resize(cenario[i],h, w);
			}catch(IOException e) {
				System.out.println("nao carregou background");
	            Logger.getLogger(Canvas.class.getName()).log(Level.SEVERE, null, e);
				
			}
			
		}
		
		
		gameLoop.start();
		
		
		
	}
	
	//instrucoes
	public void run() {
		long timer = System.currentTimeMillis();
		int frames = 0;
		
		while(true) {
			
			if(jogando) {

				if(!pausado) {
					atualiza();
				}
				repaint();
				dorme();	
			}else {
				//ta no ranking
				ranking.atualizar();
				repaint();
				dorme();
			}
			/*
			 * contador de frames
			 */
			
			frames++;			
			if(System.currentTimeMillis() - timer > 1000) {
				timer+= 1000;
				System.out.println("frames = " + frames);
				frames = 0;
			}
		}	
	}
	
	//instrucao para atualizar componentes do jogo
	public void atualiza() {
		jogador.atualizar();
		//atualiza vetor de inimigos
		
		for(int i = 0; i < inimigo.length; i++) {
			
			if(inimigo[i] != null) {
				inimigo[i].atualizarSeguir(jogador.getPosX());
				//System.out.println("sao "+ inimigo.length + "inimigos pvt");
			}
		}
		
		
	}
	//instrucao para gerar delay no thread
	public void dorme() {
		try {
			Thread.sleep(16);
		} catch(InterruptedException e) {
			Logger.getLogger(Canvas.class.getName()).log(Level.SEVERE, null, e);
		}
	}
	
	//pintura dos componentes(repaint)
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D) g.create();
		//pinta as imagens de background
		g2d.drawImage(cenario[1], null, 0,0 );
		g2d.drawImage(cenario[0], null, 0, 0);
		g2d.drawImage(cenario[2], null, 0, 0);
			
		
		//pinta o jogador
		if(jogando) {
			jogador.pintarJogador(g2d);
			//pinta vetor de inimigos
			for(int i = 0 ; i < inimigo.length; i++) {
				inimigo[i].pintarInimigo(g2d);
		
			}
			
			overlay.pintarVida(g2d, jogador.getVida());
			overlay.pintarScore(g2d, jogador.getPontuacao());
			overlay.pintarRodada(g2d, rodada);
			
			if(pausado){
				overlay.pintarPause(g2d);
			}
		
		}else{
			ranking.pintarRanking(g2d);
			//pintar ranking
			
		}
		
		
		/*
		 * teste tamanho do salto
		 * altura do retangulo deve ser a posY menos a altura do salto
		*/
		
	
		/*
		g2d.setColor(Color.black);
	    g2d.fillRect(50,375,100,100);
	    */
	}
	
	
	/*
	 * estudar esse lixos
	 * Metodo para redimensionar uma bufferedImage
	 */
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	


	public void reiniciar() {
		
		this.jogador.setVida(10);
		this.jogador.setPosX(620);
	
		//this.jogador = new Jogador( 500, 500, alturaDoPersonagem, larguraDoPersonagem, 6, 0-larguraDoPersonagem/2, w-larguraDoPersonagem/2, 10, 1, 5);
	}
	
	public void novaRodada() {
		CriarInimigos criar = new CriarInimigos(this);
		criar.start();
		
		
		
	}

	
	public void criarInimigos(int quantidadeDeInimigos) {
		
		
		
		Random random = new Random();
		
		inimigo = new Inimigo[quantidadeDeInimigos];
		for(int i = 0; i < quantidadeDeInimigos/2; i++) {
			inimigo[i] = new Inimigo( h + 1000 + random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 1 + 5*random.nextFloat(), 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
			
		}
		for(int i = quantidadeDeInimigos/2; i < quantidadeDeInimigos; i++) {
			inimigo[i] = new Inimigo( 0 - 1000 - random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 1 + 5*random.nextFloat(), 0-larguraDoPersonagem/2, h-larguraDoPersonagem/2, 10, 1, 5);
			
		}
		
		
	}
	public void setInimigo(Inimigo[] inimigo) {
		this.inimigo = inimigo;
	}
	
	public void removeInimigo() {
		
	}
	
	public UserInput getEntrada() {
		return entrada;
	}
	public Jogador getJogador() {
		return jogador;
	}
	public void setJogador(Jogador jogador) {
		this.jogador = jogador;
	}
	
	public void setPausado(boolean pausado) {
		this.pausado = pausado;
	}
	public boolean isPausado() {
		return pausado;
	}
	public void setJogando(boolean jogando) {
		this.jogando = jogando;
	}
	public boolean isJogando() {
		return jogando;
	}
	public Ranking getRanking() {
		return ranking;
	}
	public void setRodada(int rodada) {
		this.rodada = rodada;
	}
	public int getRodada() {
		return rodada;
	}
	
}
