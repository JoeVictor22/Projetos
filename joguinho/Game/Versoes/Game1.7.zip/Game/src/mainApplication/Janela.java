package mainApplication;
import java.util.Random;

import javax.swing.JFrame;

public class Janela {

	private JFrame janela;
	private Canvas jogo;
	
	private UserInput entrada;
	private UserInputRanking entradaRanking;
	private UserInputNext entradaNext;
	
	private int h;
	private int w; 
	
	public Janela(int altura, int largura) {
		this.h = altura;
		this.w = largura;
	}	
		
	public void create() {
		
		
		
		
		//definindo Jframe que usaremos
		janela = new JFrame("Nome do Jogo");
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setSize(w, h);
		janela.setResizable(false);


	
		
		
		//instanciando jogo
		jogo = new Canvas(w,h,this);

		
		//jogo.start();
		//adicionando o jogo component e seu keyListener ao JFrame criado
		janela.add(jogo);
		
		janela.setVisible(true);	
	}

	
	public void reiniciar() {
		jogo.getRanking().salvarPontuacao(jogo.getJogador().getPontuacao());
		jogo.reiniciar();
		jogo.setJogando(false);
		
		
	}
	/*
	public void reiniciarJogo() {
		jogo.reiniciar();
		addInimigo(1);
		jogo.setRodada(jogo.getRodada()+1);
		
		jogo.setJogando(true);
		entradaJogo();
	}
	*/
	
	
	public void entradaRanking() {
		entradaRanking = new UserInputRanking(this);	
		janela.removeKeyListener(entrada);
		janela.removeKeyListener(entradaNext);
		janela.addKeyListener(entradaRanking);
	}
		
	
	public void entradaJogo() {
		entrada = new UserInput(this);
		janela.removeKeyListener(entradaRanking);
		janela.removeKeyListener(entradaNext);
		janela.addKeyListener(entrada);
	}
	
	public void entradaNext() {
		entradaNext = new UserInputNext(this);
		janela.removeKeyListener(entradaRanking);
		janela.removeKeyListener(entrada);
		janela.addKeyListener(entradaNext);
	}
	
	public void reiniciarJogo() {
		/*
		 * realizar esse metodo ao eliminar todos os inimigos
		 * 
		 */
		
		addPlayer();
		addInimigo(1);
		jogo.setRodada(1);
		jogo.setJogando(true);
		entradaJogo();
		
	}
	public void proximaRodada() {
		//addInimigo(1);
		jogo.novaRodada();
		jogo.setRodada(jogo.getRodada() + 1);
		jogo.setJogando(true);
	}
	
	public void iniciarJogo() {
		/*
		if(jogo.getRodada() > 0) {
			reiniciarJogo();
		}else {*/
			addPlayer();
			addInimigo(1);
			
			jogo.setRodada(1);
			jogo.setJogando(true);
			entradaJogo();
		//}
	}
	
	public void addPlayer() {
		int alturaDoPersonagem = 100;
		int larguraDoPersonagem = 150;
		
		Jogador jogador = new Jogador( 500, 500, alturaDoPersonagem, larguraDoPersonagem, 6, 0-larguraDoPersonagem/2, w-larguraDoPersonagem/2, 10, 1, 5);
		jogo.setJogador(jogador);
	}
	
	public void addInimigo(int configuracao) {
		/*
		 * criar vetor com tipos de inimigos
		 */
		Random random = new Random();
		jogo.criarInimigos(50);
		
	}
	
	
	public Canvas getJogo() {
		return jogo;
	}
	public UserInputRanking getEntradaRanking() {
		return entradaRanking;
	}
	public int getH() {
		return h;
	}
	public int getW() {
		return w;
	}
}
