package mainApplication;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

public class Inimigo extends Personagem {
	
	/*
	 * Animacoes utilizadas pelo jogador
	 */
	private BufferedImage[] correndo;
	private BufferedImage[] parado;
	private BufferedImage[] soco;
	private BufferedImage[] morrendo;
	
	private int imagemAtual;
	private int imagemAtualSoco;
	private int imagemAtualMorte;
	
	private int timer;
	private int tempoDoSoco;
	private int tempoDaMorte;
	
	private int quantidadeDeFramesMorte;
	private int quantidadeDeFramesSoco;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	
	private boolean vivo;
	
	private int tempoPausa;

	private boolean atacando;
	private boolean eliminado;
	
	private int pausa;
	
	public Inimigo(int posX, int posY, int altura, int largura, int velocidade,int vida,int dano, int fimDaTelaEsquerda, int fimDaTelaDireita, int tempoPausa) {
		super(posX, posY, altura, largura, velocidade, vida,dano,fimDaTelaEsquerda, fimDaTelaDireita);
		//variaveis que necessitam inicializacao
		
		atacando = false;
		vivo = true;
		eliminado = false;
		
		
		timer = 0;
		imagemAtual = 0;
		imagemAtualSoco = 0;
		imagemAtualMorte = 0;
		
		tempoDoSoco = 5;
		tempoDaMorte =10;
		
		vida=2;
		dano=1;
		
		
		pausa = 0;
		this.tempoPausa = tempoPausa;
		
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 5;
		quantidadeDeFramesMorte = 9;
	}
	
	public void criarAnimacoes() {
		
		correndo = carregarImagens("Data/Sprites/Inimigo/Run/goblin-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Inimigo/Idle/goblin-idle-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Inimigo/Punch/goblin-attack-0", 5,"png");
		morrendo = carregarImagens("Data/Sprites/Inimigo/Die/goblin-die-0", 9,"png");

	}
	
	
	public void atualizar() {
//		if(vivo) {
//			System.out.println("Vivo? "+vivo);
//			if(atacando) {
//				ataca();
//			}else {
//				atualizarContadorDeImagem();
//				anda();
//			}
//		}else {
//			attImagemMorrendo();
//			System.out.println("Imagem atual : "+ imagemAtualMorte);
//			
//		}
		
	}
		
	public void pintarInimigo(Graphics2D g) {
		
		if(vivo) {
			if(!atacando) {
				if(getDirecao() != 0) {
					pintar(g, correndo, imagemAtual);
				}else  {
					pintar(g, parado, imagemAtual);
				}
			}else {
				pintar(g, soco, imagemAtualSoco);
			}	
		}
		else {
			pintar(g, morrendo , imagemAtualMorte);
		}
	}
	
		
	
	//inicia o ataque
	public void atacar() {
        if(!atacando) {
            SFX.play("Data/SFX/Attack_inimigo.wav");
            atacando = true;
            imagemAtualSoco = 0;
            timer = 0;
        }

    }
	public void ataca() {

		if(timer >= tempoDoSoco) {
			imagemAtualSoco++;
			//verifica se tem jogador
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
			}
			timer = 0;
			// leva dano
			
		}
		timer++;
	}
	
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}

	
	
	//
	//
	public void atualizarSeguir(int posXAlvo, int posYAlvo, Jogador jogador) {
		seguirPosicoes(posXAlvo, posYAlvo, jogador);
		if(atacando) {			
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}	
	}
	/*
	 * decide qual direcao andar de acordo com uma posicao alvo
	 */
	public void seguirPosicoes(int posXAlvo, int posYAlvo, Jogador jogador) {
		if(vivo) {
			if(getPosX() - posXAlvo < -60) {
				pausa = 60;
				andar(1);
			}else if(getPosX() - posXAlvo > 60){
				pausa = 60;
				andar(-1);
			}else if(getPosX() - posXAlvo > -60 && getPosX() - posXAlvo < 60 && getPosY() == posYAlvo) {
				if(pausa == tempoPausa) {
					if(getPosY() - posYAlvo <=0) {
						atacar();
						acertoAtaque(jogador);
						pausa = 0;
					}
				}
				else {
					andar(0);
					pausa++;
				}
			}
		}
		else {

			attImagemMorrendo();
		}
	}
	
	public void acertoAtaque(Jogador jogador) {
//	jogador perde vida aqui, e se ele ficar com 0 de life, a tela fecha(por enquanto soh isso) 
		if(vivo) {
			if(atacando) {
				jogador.vida -= this.dano;
				System.out.println("vida =" + jogador.getVida());
			}
			if(jogador.vida <= 0) {
				// Mostra o Overlay 2
			}
		}
	}
	
	
	
	public void recebendoDano(Jogador jogador) {
		
		if(vivo) {
			if(jogador.isFimDeAtaque()) {
				if(jogador.getPosX() - getPosX() < 120 && jogador.getPosX() - getPosX() > -120 && getPosY() == jogador.getPosY()) {
					if(jogador.getPosX() > getPosX() && jogador.getUltimaDirecao() == -1) {
						setVida(getVida() - jogador.getDano());
						stunDireita();
					}
					else if(jogador.getPosX() < getPosX() && jogador.getUltimaDirecao() == 1) {
						setVida(getVida() - jogador.getDano());
						stunEsquerda();
					}
					else if(jogador.getPosX() > getPosX() && jogador.getUltimaDirecao() == 1) {
						setVida(getVida() - 0);
					}
					else if(jogador.getPosX() < getPosX() && jogador.getUltimaDirecao() == -1) {
						setVida(getVida() - 0);
					}
				}
				else if(jogador.getPosX() - getPosX() > 120) {
					setVida(getVida() - 0);
				}
				else if(jogador.getPosX() - getPosX() < -120) {
					setVida(getVida() - 0);
				}
				else if(getPosY() == jogador.getPosY()) {
					setVida(getVida() - 0);
				}
			}
			
			if(vida <= 0) {
				morrer();
			}
		}
	}
	public void morrer() {
		this.vivo = false;
		setDirecao(0);
		timer = 0;
		
	}
	
	public void attImagemMorrendo() {
		if(timer >= tempoDaMorte) {
			imagemAtualMorte++;
			if(imagemAtualMorte == quantidadeDeFramesMorte) {
				imagemAtualMorte = 0;
				eliminado = true;
				
			}
			timer = 0;
		}
		timer++;
	}
	
	

	//STUNS LATERAIS NO INIMIGO
	public void stunDireita() {
		pausa = 0;
		setPosX(getPosX() - 5);
		//animacao levando dano
	}
	
	public void stunEsquerda() {
		pausa = 0;
		setPosX(getPosX() + 5);
		//animacao levando dano
	}
	
	
	
	public boolean isEliminado() {
		return eliminado;
	}

	public void setEliminado(boolean eliminado) {
		this.eliminado = eliminado;
	}

	public boolean isVivo() {
		return vivo;
	}

	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}

	public int getPausa() {
		return pausa;
	}

	public void setPausa(int pausa) {
		this.pausa = pausa;
	}
	
}
