package mainApplication;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class UserInputNext implements KeyListener {
	
	private Canvas jogo;
	private Ranking ranking;
	
	
	public UserInputNext(Janela janela) {
		this.jogo = janela.getJogo();
		this.ranking = jogo.getRanking();
	}
	
	/*	TODO
	 * printar na tela uma frase "Digite seu nome"
	 * aguardar as entradas do jogador e desenhar cada uma delas
	 * manter um vetor com as teclas digitadas para poder apagar e pintar a td momentos as teclas desse vetor
	 * utilizar classe ranking para fazer as pinturas
	 * 
	 */
	

	//implementacao de keyListener
	
	
	public void keyPressed(KeyEvent e) {
		if(!ranking.isEnterPressionado()){
			if(e.getKeyCode() == KeyEvent.VK_ENTER ) {
				//digitado ao menos 1 letra
				SFX.play("Data/SFX/Soco1.wav");
				ranking.enterPressionado();
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		
	}
	
	public void keyTyped(KeyEvent e) {
		
	}	

}
