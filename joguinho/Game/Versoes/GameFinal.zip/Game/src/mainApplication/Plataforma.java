package mainApplication;

public class Plataforma {

	private int posx;
	private int posy;
	
	private int largura;
	private int altura;
	
	//private Color cor;
	
	public Plataforma(int x, int y, int alt, int larg) {
		
		this.posx = x;
		this.posy = y;
		this.altura = alt;
		this.largura = larg;
		
	//	cor = Color.BLACK;
	}
	
	/*
	public void pintar(Graphics2D g) {
		
		g.setColor(cor);
		g.fillRect(posx, posy, largura, altura);
		
	}
	*/

	public int getPosx() {
		return posx;
	}

	public void setPosx(int posx) {
		this.posx = posx;
	}

	public int getPosy() {
		return posy;
	}

	public void setPosy(int posy) {
		this.posy = posy;
	}

	public int getLargura() {
		return largura;
	}

	public void setLargura(int largura) {
		this.largura = largura;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	
}
