package mainApplication;

import java.util.Random;

public class CriarInimigos extends Thread {

	private Canvas jogo;
	
	
	public CriarInimigos(Canvas jogo ) {
		this.jogo = jogo;
		

	}
	
	public void run() {
		jogo.setInimigo(criarInimigos(5));
	
		
		
	}
	
	public Inimigo[] criarInimigos(int quantidadeDeInimigos) {
		
		int alturaDoPersonagem = 100;
		int larguraDoPersonagem = 150;
		int h = 1280;
		
		Random random = new Random();
		
		
		Inimigo[] inimigo = new Inimigo[quantidadeDeInimigos];
		int vidaDoInimigo = 10;
		int danoDoInimigo = 1;
		for(int i = 0; i < quantidadeDeInimigos/2; i++) {
			
			inimigo[i] = new Inimigo( random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 2+random.nextInt(3),vidaDoInimigo,danoDoInimigo,0-larguraDoPersonagem/2, h-larguraDoPersonagem/2);
		}
		for(int i = quantidadeDeInimigos/2; i < quantidadeDeInimigos; i++) {
	
			inimigo[i] = new Inimigo( 0 - 1000 - random.nextInt(2000), 500, alturaDoPersonagem, larguraDoPersonagem, 2+random.nextInt(3),vidaDoInimigo,danoDoInimigo,0-larguraDoPersonagem/2, h-larguraDoPersonagem/2);
		}
		return inimigo;
	}
}
