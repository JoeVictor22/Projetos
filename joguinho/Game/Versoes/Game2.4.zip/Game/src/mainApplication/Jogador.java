package mainApplication;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class Jogador extends Personagem{

	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] pulo;
	BufferedImage[] soco;
	private int imagemAtual;
	private int imagemAtualSoco;
	private int imagemAtualPulo;
	
	private int timer;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	private int quantidadeDeFramesSoco;
	private int tempoDoSoco;
	
	/*
	 * Variaveis de controle
	 */
	private boolean colidindo;
	private boolean atacando;
	private boolean fimDeAtaque;
	private boolean estaNoChao;
	private boolean puloDuplo;	
	
	double aceleracao = -1.5;
	double v0 = 21.2; //14.1 = exatamente 100 pixels de pulo quando aceleracao = -1
	int posY0;
	int tempoPulo;
	int tempoDoPulo;
	
	private long pontuacao;
	
	public Jogador(int posX, int posY, int altura, int largura,int velocidade,int vida, int dano, int fimDaTelaEsquerda, int fimDaTelaDireita) {
		super(posX, posY, altura, largura, velocidade,vida,dano, fimDaTelaEsquerda, fimDaTelaDireita);
		//variaveis que necessitam inicializacao
	
		
		colidindo = false;
		atacando = false;
		fimDeAtaque = false;
		estaNoChao = true;
		puloDuplo = true;
	
		timer = 0;
				
		imagemAtual = 0;
		imagemAtualSoco = 0;
		imagemAtualPulo = 0;
		tempoDoSoco = 5;
		tempoDoPulo = 5;
	
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
		
		pontuacao = 0;
		
	}
	
	/*
	 * carrega animacoes a serem utilizadas
	 */
	public void criarAnimacoes() {
		correndo = carregarImagens("Data/Sprites/Jogador/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Jogador/Idle/adventurer-idle-0", 6, "png");
		pulo = carregarImagens("Data/Sprites/Jogador/Jump/adventurer-jump-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Jogador/Punch/adventurer-attack1-0", 3,"png");
				
		
	}
	
	//controle de posicoes e de frames
	public void atualizar() {
		/*
		 * ataca() = atualiza a imagemAtual de atacar e realiza ataque
		 * atualizarContadorDeImagem() = atualiza imagemAtual na quantidade de frames padrao definida pela gente
		 * anda() = atualiza a locomocao no eixo X do personagem
		 * pula() = realiza salto e atualiza imagemAtual de acordo com o salto
		 */
		if(estaNoChao) {
			if(atacando == true) {
				ataca();
			}else{
				atualizarContadorDeImagem();	
				anda();
			}
		}else {
			if(atacando == true) {
				ataca();
				pula();
				anda();
			}else {
				atualizarContadorDeImagem();
				pula();
				anda();
			}			
		}		
	}
	/*
	 * o tratamento quanto a direcao � feito na classe personagem
	 * nesse metodo so eh definido qual animacao sera pintar
	 */
	public void pintarJogador(Graphics2D g) {
		//se pulando
		if(!estaNoChao) {
			if(atacando == false) {
				pintar(g, pulo, imagemAtualPulo);
			}else {
				pintar(g, pulo, imagemAtualPulo);
			}
		}
		else if(!estaNoChao && puloDuplo) {
			if(atacando == false) {
				pintar(g, pulo, imagemAtualPulo);
			}else {
				pintar(g, pulo, imagemAtualPulo);
			}
		}
		else if(atacando == false){
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g,soco,imagemAtualSoco);
		}
		
	}
	
	public void pular() {
		if(estaNoChao) {
			imagemAtual = 0;
			estaNoChao = false;
			posY0 = getPosY();
			tempoPulo = 0;
			timer = 0;
		}
		else if(!estaNoChao && puloDuplo == true) {
			imagemAtual = 0 ;
			tempoPulo = 0;
			posY0 = getPosY();
			puloDuplo = false;
			timer = 0; 
		}
	}
	
	public void pula() {
		
			setPosY(((int) (posY0 - (v0 * tempoPulo + (aceleracao*tempoPulo*tempoPulo)/2 ))));
			tempoPulo++;
			if(tempoPulo<5) {
				imagemAtualPulo = 1;
			
			}else if(tempoPulo < 10 && tempoPulo >= 5) {
				imagemAtualPulo = 2;
			
			}else if(tempoPulo < 15 && tempoPulo >= 10) {
				imagemAtualPulo = 3;
			
			}else if(tempoPulo < 20 && tempoPulo >= 15) {
				imagemAtualPulo = 4;
			
			}else if(tempoPulo < 25 && tempoPulo >= 20) {
				imagemAtualPulo = 5;
				
			}
			
	}
	//atualiza imagemAtual com base em um timer
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}

	//inicia o ataque
	public void atacar() {
		if(!atacando) {
			this.atacando = true;
			this.imagemAtualSoco = 0;
			timer = 0;
		}
		
	}
	
	public void ataca() {

		if(timer >= tempoDoSoco) {
			imagemAtualSoco++;
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
				
			}
			timer = 0;
		}
		timer++;
	}
	
	public void colisao(int posXInimigo, int posYInimigo, Inimigo inimigo) {
	
		if(getPosX() + (getLargura()/3) >= posXInimigo && getPosX() < posXInimigo && getPosY() == (posYInimigo)) {	
			//quer dizer q ele ta do lado esquerdo do inimigo, logo n pode passar pro direito
			//diminui a (velocidade) em frames pela getPosX(), n o deixando entrar no inimigo
			colidindo = true;
			setPosX(getPosX() - getVelocidade());
		}
		if(getPosX() <= posXInimigo + (getLargura()/3) && getPosX() > posXInimigo && getPosY() == (posYInimigo)) {
			//quer dizer q ele ta do lado direito do inimigo, logo n pode passar pro esquerdo
			//aumenta a (velocidade) em frames pela getPosX(), n o deixando entrar no inimigo
			colidindo = true;
			setPosX(getPosX() + getVelocidade());
	
		}
		if((getPosX() >= posXInimigo + getLargura()*2/3 ) && getPosX() + getLargura() > posXInimigo +getLargura() 
		|| (getPosX() + getLargura() <= posXInimigo + (getLargura()/3) && getPosX() < posXInimigo)) {
			
			colidindo = false;
		}else {
			colidindo = true;
		}
		if( getPosY() != (posYInimigo) && 
				((getPosX() + (getLargura()/3) >= posXInimigo && getPosX() < posXInimigo) 
				|| (getPosX() <= posXInimigo + (getLargura()/3) && getPosX() > posXInimigo)) ) {
			
			inimigo.setPausa(20);
			//fica em cima ou da pulo
			//setPosY(422);
		}
		
	}
	
//	public void dandoDano(Inimigo inimigo) {
//		
//		if(fimDeAtaque ) {
//			if(getPosX() - inimigo.getPosX() < 120 && getPosX() - inimigo.getPosX() > -120 && getPosY() == inimigo.getPosY()) {
//				if(getPosX() > inimigo.getPosX() && getUltimaDirecao() == -1 ){
//					inimigo.vida -= getDano();
//					fimDeAtaque = false;
//				}
//				else if(getPosX() < inimigo.getPosX() && getUltimaDirecao() == 1){
//					inimigo.vida -= getDano();
//					fimDeAtaque = false;
//				}
//				else if(getPosX() > inimigo.getPosX() && getUltimaDirecao() == 1 ){
//					inimigo.vida += 0;
//					fimDeAtaque = false;
//				}
//				else if(getPosX() < inimigo.getPosX() && getUltimaDirecao() == 1){
//					inimigo.vida += 0;
//					fimDeAtaque = false;
//				}
//			}			
//			else if(getPosX() - inimigo.getPosX() > 120) {
//				fimDeAtaque = false;
//				inimigo.vida += 0;
//				
//			}
//			else if(getPosX() - inimigo.getPosX() > -120){
//				fimDeAtaque = false;
//				inimigo.vida += 0;
//			}
//			else if(getPosY() == inimigo.getPosY()) {
//				fimDeAtaque = false;
//				inimigo.vida += 0;
//			}
//			
//		}
//		
//		
//		
//	}
	/*
	 * Metodos de acesso
	 */
	
	public long getPontuacao() {
		return pontuacao;
	}
	public void setPontuacao(long pontuacao) {
		this.pontuacao = pontuacao;
	}
	
	public int getImagemAtual() {
		return imagemAtual;
	}

	public boolean isPuloDuplo() {
		return puloDuplo;
	}

	public void setPuloDuplo(boolean puloDuplo) {
		this.puloDuplo = puloDuplo;
	}

	public boolean isAtacando() {
		return atacando;
	}

	public boolean isColidindo() {
		return colidindo;
	}

	public void setColidindo(boolean colidindo) {
		this.colidindo = colidindo;
	}

	public void setImagemAtual(int imagemAtual) {
		this.imagemAtual = imagemAtual;
	}

	public int getQuantidadeDeFrames() {
		return quantidadeDeFrames;
	}

	public void setQuantidadeDeFrames(int quantidadeDeFrames) {
		this.quantidadeDeFrames = quantidadeDeFrames;
	}

	public boolean isFimDeAtaque() {
		return fimDeAtaque;
	}

	public void setFimDeAtaque(boolean fimDeAtaque) {
		this.fimDeAtaque = fimDeAtaque;
	}

	public boolean isEstaNoChao() {
		return estaNoChao;
	}

	public void setEstaNoChao(boolean estaNoChao) {
		this.estaNoChao = estaNoChao;
	}
	
}
