package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class Ranking {

	private int h;
	private int w;
	
	private UserInputRanking input;
	private Janela janela;
	private long pontuacao;
	
	private int limiteFrames;
	private int imagemAtual;
	private int timer;
	private int velocidadeDasAnimacoes;
	
	private boolean enterPressionado;
	
	//controle de entradas
	private boolean trocado1;
	private boolean trocado2;
	
	private BufferedImage[] fundo;
	
	public Ranking(Janela janela){
		this.h = janela.getH();
		this.w = janela.getW();
		this.janela = janela;
		this.input = janela.getEntradaRanking();
		
		this.trocado1 = false;
		this.trocado2 = false;
		
		this.pontuacao = 0;
		
		
		this.limiteFrames = 5;
		this.imagemAtual = 0;
		this.timer = 0;
		this.velocidadeDasAnimacoes = 15;
		
		this.enterPressionado = false;
		
		fundo = carregarImagens("Data/Extra/Ranking/", 10, "png");
		for(int i = 0; i < 10; i++) {
			fundo[i] = resize(fundo[i],w,h);
		}
		
		
	}
	
	
	public void atualizar(){
		// se n tiver terminado animacao
		if(imagemAtual < limiteFrames) {
			atualizarImagem();
		//se tiver terminado
		}else if(imagemAtual == 9){
			/*
			 * resetar tds os atributos de controle
			 */
			janela.iniciarJogo();
			imagemAtual = 0;
			limiteFrames = 5;
			enterPressionado = false;
			trocado1 = false;
			trocado2 = false;
		}
		else {
			
		}
	}
	
	
	public void pintarRanking(Graphics2D g) {
		pintarFundo(g);
		if(imagemAtual == 5) {
			if(!enterPressionado) {
				if(trocado1 == false) {
					janela.entradaNext();
					trocado1 = true;
				}
				pintarClassificacao(g);
			}else {
				if(pontuacao == 0) {
					terminarAnimacao();
				}else {
					//System.out.println("pq q eh q tu n vai pvt");
					if(trocado2 == false) {
						janela.entradaRanking();
						trocado2 = true;
						//System.out.println("hein meu");
					}
					//System.out.println("pq?");
					pintarLetras(g);
				}
			}
			
			
		}	
		
	
	}
	
	public void mostrarRanking() {
		this.pontuacao = 0;
		this.enterPressionado = false;
		this.trocado1 = false;
	}
	public void pintarClassificacao(Graphics2D g) {
		/*
		 * aqui se deve pintar a classificacao de acordo com o arquivo de ranking
		 */
		g.fillRect(200, 200, 500, 500);
		g.setColor(Color.black);
	}
	
	public void pintarFundo(Graphics2D g) {
		/*
		 * aqui pinta se o sprite do plano de fundo
		 */
		g.drawImage(fundo[imagemAtual],null,0,0);
	}
	
	public void pintarLetras(Graphics2D g) {
		/*
		 * aqui deve se atualizar um char a cada ciclo e pintar as letras correspondentes no centro da tela
		 */
		//char[] nome = input.getNome();
		char[] nome = new char[3];
		nome[0] = ' ';
		nome[1] = ' ';
		nome[2] = ' ';
	//	System.out.println(nome[0] + " " + nome[1] + " " + nome[2]);
	}
	
	//atualiza imagemAtual com base em um timer
	public void atualizarImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			timer = 0;
		}
		timer++;
	}
	
	public void salvarPontuacao(long pontuacao) {
		this.pontuacao = pontuacao;
	}

	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				Logger.getLogger(Personagem.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
		
	}
	
	public void terminarAnimacao() {
		this.limiteFrames = 9;
	
		/*
		if(janela.getJogo().getJogador() == null) {
			pontuacao = 0;
		}else {
			pontuacao = janela.getJogo().getJogador().getPontuacao();
		}
		*/
		
		System.out.println("pontuacao = " + pontuacao);
		
	}
	public void enterPressionado() {
		this.enterPressionado = true;
	}
	public boolean isEnterPressionado() {
		return enterPressionado;
	}
}
