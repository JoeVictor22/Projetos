package mainApplication;
import java.util.Random;

import javax.swing.JFrame;

public class Janela {

	private JFrame janela;
	private Canvas jogo;
	
	private UserInput entrada;
	private UserInputRanking entradaRanking;
	private UserInputNext entradaNext;
	
	private int h;
	private int w; 
	
	public Janela(int altura, int largura) {
		this.h = altura;
		this.w = largura;
	}	
		
	public void create() {
		
		
		
		
		//definindo Jframe que usaremos
		janela = new JFrame("Nome do Jogo");
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.setSize(w, h);
		janela.setResizable(false);


	
		
		
		//instanciando jogo
		jogo = new Canvas(w,h,this);
		
		
		//jogo.start();
		//adicionando o jogo component e seu keyListener ao JFrame criado
		janela.add(jogo);
		
		janela.setVisible(true);	
	}

	
	public void reiniciar() {
		BGM.stop();
		jogo.getRanking().salvarPontuacao(jogo.getJogador().getPontuacao());
		jogo.reiniciar();
		jogo.setJogando(false);
		
		
	}
	/*
	public void reiniciarJogo() {
		jogo.reiniciar();
		addInimigo(1);
		jogo.setRodada(jogo.getRodada()+1);
		
		jogo.setJogando(true);
		entradaJogo();
	}
	*/
	
	
	public void entradaRanking() {
		entradaRanking = new UserInputRanking(this);	
		janela.removeKeyListener(entrada);
		janela.removeKeyListener(entradaNext);
		janela.addKeyListener(entradaRanking);
	}
		
	
	public void entradaJogo() {
		entrada = new UserInput(this);
		janela.removeKeyListener(entradaRanking);
		janela.removeKeyListener(entradaNext);
		janela.addKeyListener(entrada);
	}
	
	public void entradaNext() {
		entradaNext = new UserInputNext(this);
		janela.removeKeyListener(entradaRanking);
		janela.removeKeyListener(entrada);
		janela.addKeyListener(entradaNext);
	}
	
	//inutilizado
	public void reiniciarJogo() {
		/*
		 * realizar esse metodo ao eliminar todos os inimigos
		 * 
		 */
		
		addPlayer();
		addInimigo(1);
		jogo.setRodada(1);
		jogo.setJogando(true);
		entradaJogo();
		
	}
	public void proximaRodada() {
		//addInimigo(1);
		jogo.novaRodada();
		jogo.setRodada(jogo.getRodada() + 1);
		jogo.setJogando(true);
	}
	
	public void iniciarJogo() {
		/*
		if(jogo.getRodada() > 0) {
			reiniciarJogo();
		}else {*/
			addPlayer();
			addInimigo(1);
            BGM.play("Data/SFX/SFIICE_Guile_UAZ.mid"); //Toca BGM SOUNDS
			jogo.setRodada(1);
			jogo.setJogando(true);
			entradaJogo();
		//}
	}
	
	public void addPlayer() {
		int alturaDoPersonagem = 100;
		int larguraDoPersonagem = 150;
		int vidaDoJogador = 20;
		int danoDoJogador = 1;;
		
		Jogador jogador = new Jogador( 580, 500, alturaDoPersonagem, larguraDoPersonagem, 6,vidaDoJogador,danoDoJogador, 0-(larguraDoPersonagem/2)+36, w-(larguraDoPersonagem/2)-54);
		jogo.setJogador(jogador);
	}
	
	public void addInimigo(int configuracao) {
		/*
		 * criar vetor com tipos de inimigos
		 */

		jogo.criarInimigos(5);
		
	}
	
	
	public Canvas getJogo() {
		return jogo;
	}
	public UserInputRanking getEntradaRanking() {
		return entradaRanking;
	}
	public int getH() {
		return h;
	}
	public int getW() {
		return w;
	}
}
