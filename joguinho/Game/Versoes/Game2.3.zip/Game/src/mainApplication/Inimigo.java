package mainApplication;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;

public class Inimigo extends Personagem {
	
	/*
	 * Animacoes utilizadas pelo jogador
	 */
	BufferedImage[] correndo;
	BufferedImage[] parado;
	BufferedImage[] soco;
	private int imagemAtual;
	private int imagemAtualSoco;
	private int timer;
	private int tempoDoSoco;
	private int quantidadeDeFramesSoco;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	

	private boolean atacando;
	
	private int pausa;
	
	public Inimigo(int posX, int posY, int altura, int largura, int velocidade,int vida,int dano, int fimDaTelaEsquerda, int fimDaTelaDireita) {
		super(posX, posY, altura, largura, velocidade, vida,dano,fimDaTelaEsquerda, fimDaTelaDireita);
		//variaveis que necessitam inicializacao
		
		atacando = false;
		
		timer = 0;
		imagemAtual = 0;
		imagemAtualSoco = 0;
		tempoDoSoco = 5;
		
		vida=2;
		dano=1;
		
		pausa = 0;
		//velocidadeDasAnimacoes; quanto menor mais rapido
		velocidadeDasAnimacoes= 12;
		//quantidadeDeFrames deve ser igual ao tamanho das animacoes usado no criar imagens - 1
		quantidadeDeFrames = 5;
		//quantidadeDeFramesSoco deve ser igual a quantidade de frames que ele possui
		quantidadeDeFramesSoco = 3;
	}
	
	public void criarAnimacoes() {
		
		correndo = carregarImagens("Data/Sprites/Jogador/Run/adventurer-run-0", 6, "png");
		parado = carregarImagens("Data/Sprites/Jogador/Idle/adventurer-idle-0", 6, "png");
		soco = carregarImagens("Data/Sprites/Jogador/Punch/adventurer-attack1-0", 3,"png");

	}
	
	
	public void atualizar() {
		if(atacando) {
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}
		
	}
		
	public void pintarInimigo(Graphics2D g) {
		
		if(!atacando) {
			if(getDirecao() != 0) {
				pintar(g, correndo, imagemAtual);
			}else  {
				pintar(g, parado, imagemAtual);
			}
		}else {
			pintar(g, soco, imagemAtualSoco);
		}
	}
	
	//inicia o ataque
	public void atacar() {
		if(!atacando) {
			atacando = true;
			imagemAtualSoco = 0;
			timer = 0;
		}
		
	}
	
	/*
	 * implementar aq algum tipo de verificacao de colisao para saber se o ataque atingiu algum inimigo
	 * cria um contador menor para a animacao do soco
	 * e verifica se tem inimigos na regiao prox
	 */
	public void ataca() {

		if(timer >= tempoDoSoco) {
			imagemAtualSoco++;
			//verifica se tem jogador
			if(imagemAtualSoco == quantidadeDeFramesSoco) {
				imagemAtualSoco = 0;
				atacando = false;
			}
			timer = 0;
			// leva dano
			
		}
		timer++;
	}
	
	public void atualizarContadorDeImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 0;
			}
			timer = 0;
		}
		timer++;
	}

	
	//
	//
	public void atualizarSeguir(int posXAlvo, int posYAlvo, Jogador jogador) {
		seguirPosicoes(posXAlvo, posYAlvo, jogador);
		if(atacando) {
			
			ataca();
		}else {
			atualizarContadorDeImagem();
			anda();
		}	
	}
	/*
	 * decide qual direcao andar de acordo com uma posicao alvo
	 */
	public void seguirPosicoes(int posXAlvo, int posYAlvo, Jogador jogador) {
		
		if(getPosX() - posXAlvo < -60) {
			pausa = 60;
			andar(1);
		}else if(getPosX() - posXAlvo > 60){
			pausa = 60;
			andar(-1);
		}else if(getPosX() - posXAlvo > -60 && getPosX() - posXAlvo < 60 && getPosY() == posYAlvo) {
			if(pausa == 80) {
				if(getPosY() - posYAlvo <=0) {
					atacar();
					acertoAtaque(jogador);
					pausa = 0;
				}
			}
			else {
				andar(0);
				pausa++;
			}
		}
		
	}
	
	public void acertoAtaque(Jogador jogador) {
//	jogador perde vida aqui, e se ele ficar com 0 de life, a tela fecha(por enquanto soh isso) 
		if(atacando) {
			jogador.vida -= this.dano;
			System.out.println("vida =" + jogador.getVida());
		}
		if(jogador.vida <= 0) {
			// Mostra o Overlay 2
		}
		
	}
	
	
	
	public void recebendoDano(Jogador jogador) {
		
		if(jogador.isFimDeAtaque()) {
			if(jogador.getPosX() - getPosX() < 120 && jogador.getPosX() - getPosX() > -120 && getPosY() == jogador.getPosY()) {
				if(jogador.getPosX() > getPosX() && jogador.getUltimaDirecao() == -1) {
					setVida(getVida() - jogador.getDano());
					stunDireita();
				}
				else if(jogador.getPosX() < getPosX() && jogador.getUltimaDirecao() == 1) {
					setVida(getVida() - jogador.getDano());
					stunEsquerda();
				}
				else if(jogador.getPosX() > getPosX() && jogador.getUltimaDirecao() == 1) {
					setVida(getVida() - 0);
				}
				else if(jogador.getPosX() < getPosX() && jogador.getUltimaDirecao() == -1) {
					setVida(getVida() - 0);
				}
			}
			else if(jogador.getPosX() - getPosX() > 120) {
				setVida(getVida() - 0);
			}
			else if(jogador.getPosX() - getPosX() < -120) {
				setVida(getVida() - 0);
			}
			else if(getPosY() == jogador.getPosY()) {
				setVida(getVida() - 0);
			}
		}
		
		
	}
	

	//STUNS LATERAIS NO INIMIGO
	public void stunDireita() {
		pausa = 0;
		setPosX(getPosX() - 5);
		//animacao levando dano
	}
	
	public void stunEsquerda() {
		pausa = 0;
		setPosX(getPosX() + 5);
		//animacao levando dano
	}
	
	public boolean morto() {
		if(getVida() <= 0) {
			return true;
		}else {
			return false;
		}
	}
	
	
	public int getPausa() {
		return pausa;
	}

	public void setPausa(int pausa) {
		this.pausa = pausa;
	}
	
}
