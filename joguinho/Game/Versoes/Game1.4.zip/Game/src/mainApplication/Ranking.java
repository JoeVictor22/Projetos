package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class Ranking {

	private int h;
	private int w;
	
	private UserInputRanking input;
	private Janela janela;
	
	private int limiteFrames;
	private int imagemAtual;
	private int timer;
	private int velocidadeDasAnimacoes;
	
	private boolean enterPressionado;
	
	private BufferedImage[] fundo;
	
	public Ranking(int h, int w, Janela janela){
		this.h = h;
		this.w = w;
		this.janela = janela;
		this.input = janela.getEntradaRanking();
		
	
		this.limiteFrames = 5;
		this.imagemAtual = 0;
		this.timer = 0;
		this.velocidadeDasAnimacoes = 15;
		
		this.enterPressionado = false;
		
		fundo = carregarImagens("Data/Extra/Ranking/", 10, "png");
		for(int i = 0; i < 10; i++) {
			fundo[i] = resize(fundo[i],h,w);
		}
		
		
	}
	
	
	public void atualizar(){
		if(imagemAtual < limiteFrames) {
			atualizarImagem();
		}else if(imagemAtual == 9){
			/*
			 * resetar tds os atributos de controle
			 */
			janela.iniciarJogo();
			imagemAtual = 0;
			limiteFrames = 5;
			enterPressionado = false;
		}
	}
	
	
	public void pintarRanking(Graphics2D g) {
		
		if(imagemAtual == 5) {
			if(!enterPressionado) {
				janela.entradaNext();
				pintarClassificacao(g);
			}else {
				janela.entradaRanking();
				pintarLetras(g);
			}
			
			
		}	
		
		pintarFundo(g);
	}
	
	
	public void pintarClassificacao(Graphics2D g) {
		/*
		 * aqui se deve pintar a classificacao de acordo com o arquivo de ranking
		 */
		g.fillRect(200, 200, 500, 500);
		g.setColor(Color.black);
	}
	
	public void pintarFundo(Graphics2D g) {
		/*
		 * aqui pinta se o sprite do plano de fundo
		 */
		g.drawImage(fundo[imagemAtual],null,0,0);
	}
	
	public void pintarLetras(Graphics2D g) {
		/*
		 * aqui deve se atualizar um char a cada ciclo e pintar as letras correspondentes no centro da tela
		 */
		//char[] nome = input.getNome();
		char[] nome = new char[3];
		nome[0] = ' ';
		nome[1] = ' ';
		nome[2] = ' ';
	//	System.out.println(nome[0] + " " + nome[1] + " " + nome[2]);
	}
	
	//atualiza imagemAtual com base em um timer
	public void atualizarImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			timer = 0;
		}
		timer++;
	}

	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				Logger.getLogger(Personagem.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
		
	}
	
	public void terminarAnimacao() {
		this.limiteFrames = 9;
		
	}
	public void enterPressionado() {
		this.enterPressionado = true;
	}
	public boolean isEnterPressionado() {
		return enterPressionado;
	}
}
