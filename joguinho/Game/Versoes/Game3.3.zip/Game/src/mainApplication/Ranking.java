package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class Ranking {

	private int h;
	private int w;

	private Janela janela;
	private long pontuacao;
	
	private int limiteFrames;
	private int imagemAtual;
	private int timer;
	private int velocidadeDasAnimacoes;
	
	private boolean enterPressionado;
	
	//controle de entradas
	private boolean trocado1;
	private boolean trocado2;
	
	private BufferedImage[] fundo;
	
	private BufferedImage[] letras;
	
	private BufferedImage[] numeros;
	
	private BufferedImage digiteNome;
	private BufferedImage barra;
	private BufferedImage enter;
	
	private BufferedImage rodadaImagem;
	
	private Arquivo arquivoRank;
	private String[] rank;
	
	private BufferedImage rankImagem;
	
	char[] nome;
	
	public Ranking(Janela janela){
		this.h = janela.getH();
		this.w = janela.getW();
		this.janela = janela;
		
		this.trocado1 = false;
		this.trocado2 = false;
		
		this.pontuacao = 0;
		
		
		this.limiteFrames = 5;
		this.imagemAtual = 0;
		this.timer = 0;
		this.velocidadeDasAnimacoes = 6;
		
		this.enterPressionado = false;
		
		enter = carregarImagem("Data/Extra/Ranking/enter.png");
		barra = carregarImagem("Data/Extra/Ranking/barra.png");
		digiteNome = carregarImagem("Data/Extra/Ranking/digitarNome.png");
		
		digiteNome = resize(digiteNome,40*15,40);
		barra = resize(barra,40,40);
		enter = resize(enter, 80,80);
		
		fundo = carregarImagens("Data/Extra/Ranking/", 10, "png");
		for(int i = 0; i < 10; i++) {
			fundo[i] = resize(fundo[i],w,h);
		}
		
		letras = carregarImagens2("Data/Extra/Ranking/Letras/0", 26, "png");
		for(int i = 0; i < letras.length-2; i++) {
			letras[i] = resize(letras[i], 40, 40);
		}
	
		
		numeros = carregarImagens("Data/Sprites/Alfabeto/",11,"png");
		for(int i = 0; i < numeros.length-1; i++) {
			numeros[i] = resize(numeros[i], 40, 40);
		}
		numeros[10] = resize(numeros[10], 40*5, 40);
		
		rodadaImagem = carregarImagem("Data/Sprites/Alfabeto/rodada.png"); 
		rodadaImagem = resize(rodadaImagem, 40*6,40);		
		
		arquivoRank = new Arquivo();
		rank = arquivoRank.ler();
		
		this.rankImagem = carregarImagem("Data/Extra/Ranking/rank.png");
		this.rankImagem = resize(rankImagem, 50*4, 50);
	}
	
	
	public void atualizar(){
		// se n tiver terminado animacao
		if(imagemAtual < limiteFrames) {
			atualizarImagem();
		//se tiver terminado
		}else if(imagemAtual == 9){
			/*
			 * resetar tds os atributos de controle
			 */
			janela.iniciarJogo();
			imagemAtual = 0;
			limiteFrames = 5;
			enterPressionado = false;
			trocado1 = false;
			trocado2 = false;
		}
		else {
			
		}
	}
	
	
	public void pintarRanking(Graphics2D g) {
		pintarFundo(g);
		if(imagemAtual == 5) {
			if(!enterPressionado) {
				if(trocado1 == false) {
					janela.entradaNext();
					trocado1 = true;
				}
				pintarClassificacao(g);
			}else {
				if(pontuacao == 0) {
					terminarAnimacao();
				}else {
					//System.out.println("pq q eh q tu n vai pvt");
					if(trocado2 == false) {
						janela.entradaRanking();
						trocado2 = true;
						//System.out.println("hein meu");
					}
					/*
					 * pintar pontuacao e rounds jogados
					 */
					pintarPontuacao(g);
					pintarRodada(g);
					pintarLetras(g);
					
				}
			}
			
			
		}	
		
	
	}
	public void pintarPontuacao(Graphics2D g){
		
		
		/*
		 * contador j define o espacamento
		 * contador i comeca do ultimo caractere
		 */
		g.drawImage(numeros[10], null, 850,200 );
		for(int j = 0, i =Long.toString(janela.getJogo().getJogador().getPontuacao()).length()-1; i >= 0; i--, j++) {
			//System.out.println("A posicao eh " + (pontuacao.charAt(i) - '0'));
			g.drawImage(numeros[Long.toString(janela.getJogo().getJogador().getPontuacao()).charAt(i) - '0'], null, 800+ 40 *5 - 40*j,  240);
		}
	}
	public void pintarRodada(Graphics2D g) {

		g.drawImage(rodadaImagem, null, 150,  200);
		
		for(int j = 0, i = Integer.toString(janela.getJogo().getRodada()).length()-1; i >= 0; i--, j++) {
			//System.out.println("A posicao eh " + (pontuacao.charAt(i) - '0'));
			g.drawImage(numeros[Integer.toString(janela.getJogo().getRodada()).charAt(i) - '0'], null,  200+ 40*4  - 40*j, 240);
		}
		
		
	}
	
	
	public void mostrarRanking() {
		this.rank = arquivoRank.ler();
		this.pontuacao = 0;
		this.enterPressionado = false;
		this.trocado1 = false;
	}
	public void pintarClassificacao(Graphics2D g) {
		/*
		 * aqui se deve pintar a classificacao de acordo com o arquivo de ranking
		 */
		int posX = w/2 - 40*5;
		int centerX = w/2;
		int posY = h/2 - 40*6;
		
		g.drawImage(rankImagem, null, centerX - 40*3, 20);
		
		for(int i = 0 ; i < 10; i++) {
			for(int j = 0;j < 3; j++) {
				g.drawImage(letras[rank[i].charAt(j)- 'a'],null,posX + j* 40,posY + i*50);
				g.drawImage(barra, null, posX + 40*4, posY + 10 +i*50);
			}
		}
		for(int i = 10 ; i < 20; i++) {
			for(int j = 0;j < rank[i].length(); j++) {
				g.drawImage(numeros[rank[i].charAt(j)- '0'],null, posX + 40*6 + j* 40,posY + (i-10)*50);
			}
		}
		
		
		
		
		/*
		g.drawImage(rankImagem, null, 450, 20);
		
		for(int i = 0 ; i < 10; i++) {
			for(int j = 0;j < 3; j++) {
				g.drawImage(letras[rank[i].charAt(j)- 'a'],null,350 + j* 40,100 + i*50);
				g.drawImage(letras[5], null, 520, 110+i*50);
			}
		}
		for(int i = 10 ; i < 20; i++) {
			for(int j = 0;j < rank[i].length(); j++) {
				g.drawImage(numeros[rank[i].charAt(j)- '0'],null,650 + j* 40,100 + (i-10)*50);
			}
		}
		
		*/
		
		System.out.println("\nRank");
		for(int i = 0 ; i < 10; i++) {
			System.out.println(rank[i] + " : " + rank[i+10]);
		}
		
	}
	
	public void pintarFundo(Graphics2D g) {
		/*
		 * aqui pinta se o sprite do plano de fundo
		 */
		g.drawImage(fundo[imagemAtual],null,0,0);
	}
	
	public void pintarLetras(Graphics2D g) {
		/*
		 * aqui deve se atualizar um char a cada ciclo e pintar as letras correspondentes no centro da tela
		 */
		
		
		nome = janela.getEntradaRanking().getNome();
		g.drawImage(digiteNome,null,370,400);
		if(janela.getEntradaRanking().getContador()+1 < 4) {
			g.drawImage(barra,null,400+ 100*(janela.getEntradaRanking().getContador()+1),570);
		}
		
		if(nome[0]-'a' >= 0) {
			g.drawImage(letras[nome[0]-'a'],null,400 + 100,500);
		}
		if(nome[1]-'a' >= 0) {
			g.drawImage(letras[nome[1]-'a'],null,400 + 200,500);	
		}
		if(nome[2]-'a' >= 0) {
			g.drawImage(letras[nome[2]-'a'],null,400 + 300,500);
		}
		if(janela.getEntradaRanking().getContador() > 0) {
			//pintar enter
			g.drawImage(enter,null,400 + 400, 480);
		}
		
		
		System.out.println(nome[0] + " " + nome[1] + " " + nome[2]);
	}
	
	//atualiza imagemAtual com base em um timer
	public void atualizarImagem() {
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			timer = 0;
		}
		timer++;
	}
	
	public void salvarPontuacao(long pontuacao) {
		this.pontuacao = pontuacao;
	}

	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				Logger.getLogger(Personagem.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
		
	}
	

	public BufferedImage[] carregarImagens2(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + (i+1) + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				Logger.getLogger(Personagem.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
		
	}
	
	
	public void terminarAnimacao() {
		this.limiteFrames = 9;
		
		
		
	}
	public void atualizarRank() {

		// TODO
		//colocar algum limitador de pontuacao
		int x = 20;
		
		for(int i = 19; i > 9; i--) {
			if(pontuacao > Long.parseLong(rank[i])) {
				x--;
			}
		}
		if(x < 20) {

			for(int j = 19 ; j > x; j--) {
				rank[j] = rank[j-1 ]; 
				rank[j-10] = rank[j-11];
			}
			
			rank[x] = Long.toString(pontuacao);	
			rank[x-10] = nome[0] +""+ nome[1] +""+ nome[2];
			
		}
				
		try {
			arquivoRank.escrever(rank);
		} catch (IOException e) {
			System.out.println("nao salvou");
			e.printStackTrace();
		}
		
	}
		
	public BufferedImage carregarImagem(String enderecoComExtensao) {
		//BufferedImage imagem = new BufferedImage(null, null, false, null);
			
		try {
			BufferedImage imagem = ImageIO.read(new File(enderecoComExtensao));
			return imagem;
		}catch(IOException e) {
			System.out.println("Metodo carregarImagens : nao carregou imagem = "+ enderecoComExtensao);
			Logger.getLogger(Overlay.class.getName()).log(Level.SEVERE, null, e);
			return null;
		}
	
		
		
	}
	
	public void enterPressionado() {
		this.enterPressionado = true;
	}
	public boolean isEnterPressionado() {
		return enterPressionado;
	}
}
