package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class Overlay {

	private int altura = 50;
	private int largura = 50;
	
	private int h;
	private int w;
	
	private BufferedImage[] numeros;
	private BufferedImage[] overlay;
	private BufferedImage rodadaImagem;
	
	private int posXLetras;
	private int posYLetras;
	private int espacamento;
	
	private int imagemAtual;
	private int timer;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	
	public Overlay(int h, int w){
		this.h = h;
		this.w = w;
		this.imagemAtual= 1;
		this.timer = 1;
		this.velocidadeDasAnimacoes = 5;
		this.quantidadeDeFrames = 10;
		
		numeros = carregarImagens("Data/Sprites/Alfabeto/",11,"png");
		for(int i = 0; i < numeros.length; i++) {
			numeros[i] = resize(numeros[i], 30, 30);
		}
		overlay = new BufferedImage[8];
		overlay = carregarImagens("Data/Extra/",14,"png");
		overlay[0] = resize(overlay[0], h,w);
		
		rodadaImagem = carregarImagem("Data/Sprites/Alfabeto/rodada.png"); 
		rodadaImagem = resize(rodadaImagem, 30*6,30);		
				
		
		for(int i = 1; i < 8;i++) {
			overlay[i] = resize(overlay[1], 20*6 + 10*i, 20 + 2*i);
			overlay[6+i] = resize(overlay[1], 20*6 + 10*(6-i), 20 + 2*(6-i));
		}
		
		
		numeros[10] = resize(numeros[10], 30*5, 30);
		posXLetras = 1200;
		posYLetras = 50;
		espacamento = 30;
	}

	
	public void pintarPause(Graphics2D g) {
		g.drawImage(overlay[0], null, 0,0);
		g.drawImage(overlay[imagemAtual],null,h/2 - 30*3,w/2 - 15);
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 1;
			}
			timer = 1;
		}
		timer++;
	}
	
	public void pintarRodada(Graphics2D g, int rodada) {
		
		if(rodada > 999999) {
			rodada = 999999;
		}
		
		g.drawImage(rodadaImagem, null, posXLetras-30*5,  posYLetras - 35);
		
		for(int j = 0, i = Integer.toString(rodada).length()-1; i >= 0; i--, j++) {
			//System.out.println("A posicao eh " + (pontuacao.charAt(i) - '0'));
			g.drawImage(numeros[Integer.toString(rodada).charAt(i) - '0'], null, posXLetras - espacamento*j, posYLetras);
		}
		
	}
	
	public void pintarVida(Graphics2D g, int vida) {
		
		
		
		for(int i = 0; i < vida ; i++) {
			g.setColor(Color.red);
			g.fillRect(40+ (largura+1)*i,40,largura,altura);
		}
	}
	
	public void pintarScore(Graphics2D g, long score) {
		
		/*
		 * TO DO
		 * Printar palavra score
		 */
		
		//converte o score para string
		if(score < 0) {
			score = 0;
		}
		String pontuacao = Long.toString(score);
		//System.out.println("long ta : " + score + " ja a string ta : " + pontuacao);
		
		/*
		 * contador j define o espacamento
		 * contador i comeca do ultimo caractere
		 */
		g.drawImage(numeros[10], null, posXLetras - 350, posYLetras - 35);
		for(int j = 0, i = pontuacao.length()-1; i >= 0; i--, j++) {
			//System.out.println("A posicao eh " + (pontuacao.charAt(i) - '0'));
			g.drawImage(numeros[pontuacao.charAt(i) - '0'], null, posXLetras - 230-espacamento*j, posYLetras);
		}
		
	}
	
	
	
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
				 Logger.getLogger(Overlay.class.getName()).log(Level.SEVERE, null, e);
			}
			
		}
		return imagem;
	}
	
	public BufferedImage carregarImagem(String enderecoComExtensao) {
		//BufferedImage imagem = new BufferedImage(null, null, false, null);
			
		try {
			BufferedImage imagem = ImageIO.read(new File(enderecoComExtensao));
			return imagem;
		}catch(IOException e) {
			System.out.println("Metodo carregarImagens : nao carregou imagem = "+ enderecoComExtensao);
			Logger.getLogger(Overlay.class.getName()).log(Level.SEVERE, null, e);
			return null;
		}
		
	
		
	}
	
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	
}
