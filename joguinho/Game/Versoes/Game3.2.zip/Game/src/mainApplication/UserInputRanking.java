package mainApplication;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class UserInputRanking implements KeyListener {

	private Jogador jogador;
	private Canvas jogo;
	private Janela janela;
	private Ranking ranking;
	
	private char nome[] = new char[3];
	private int contador;
	

	
	public UserInputRanking(Janela janela) {
		this.janela = janela;
		this.jogo = janela.getJogo();
		this.jogador = jogo.getJogador();
		this.ranking = jogo.getRanking();
		this.contador = 0;
		
		/*
		this.nome[0] = ' ';
		this.nome[1] = ' ';
		this.nome[2] = ' ';
		*/
		//TESTE
		this.nome[0] = ' ';
		this.nome[1] = ' ';
		this.nome[2] = ' ';
	}
	
	/*	TODO
	 * printar na tela uma frase "Digite seu nome"
	 * aguardar as entradas do jogador e desenhar cada uma delas
	 * manter um vetor com as teclas digitadas para poder apagar e pintar a td momentos as teclas desse vetor
	 * utilizar classe ranking para fazer as pinturas
	 * 
	 */
	

	//implementacao de keyListener
	
	
	public void keyPressed(KeyEvent e) {
		
		if(!jogo.isJogando() && ranking.isEnterPressionado()) {
			//System.out.println(nome[0] +" " + nome[1] + " "+ nome[2]);
			if(contador < 3 ) {
				if(e.getKeyCode() == KeyEvent.VK_A) {
					SFX.play("Data/SFX/Soco1.wav");
					nome[contador] = 'a';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_S) {
					nome[contador] = 's';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_D) {
					nome[contador] = 'd';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_F) {
					nome[contador] = 'f';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_G) {
					nome[contador] = 'g';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_H) {
					nome[contador] = 'h';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_J) {
					nome[contador] = 'j';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_K) {
					nome[contador] = 'k';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_L) {
					nome[contador] = 'l';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_Q) {
					nome[contador] = 'q';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_W) {
					nome[contador] = 'w';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_E) {
					nome[contador] = 'e';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_R) {
					nome[contador] = 'r';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_T) {
					nome[contador] = 't';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_Y) {
					nome[contador] = 'y';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_U) {
					nome[contador] = 'u';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_I) {
					nome[contador] = 'i';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_O) {
					nome[contador] = 'o';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_P) {
					nome[contador] = 'p';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_Z) {
					nome[contador] = 'z';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_X) {
					nome[contador] = 'x';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_C) {
					SFX.play("Data/SFX/Soco1.wav");
					nome[contador] = 'c';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_V) {
					nome[contador] = 'v';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_B) {
					SFX.play("Data/SFX/Soco1.wav");
					nome[contador] = 'b';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_N) {
					nome[contador] = 'n';
					contador++;
				}
				if(e.getKeyCode() == KeyEvent.VK_M) {
					nome[contador] = 'm';
					contador++;
				}
			}	
				
			// enter e del
			if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
				System.out.println(nome[0] +" " + nome[1] + " "+ nome[2]);
				if(contador > 0) {
					SFX.play("Data/SFX/Soco1.wav");
					//nome[contador-1] = ' ';
					//teste
					nome[contador-1] = ' ';
					contador--;	
				//	System.out.println(nome[0] +" " + nome[1] + " "+ nome[2]);
				}
			}	
			if(e.getKeyCode() == KeyEvent.VK_ENTER ) {
				//digitado ao menos 1 letra
				if(contador > 0) {
					
					while(contador < 3) {
						//nome[contador] = ' ';
						//teste
						nome[contador] = ' ';
						contador++;
					}
					SFX.play("Data/SFX/Soco1.wav");
					//criar arquivo rank
					ranking.atualizarRank();
					ranking.mostrarRanking();
					
					contador = 0;
				}
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		
	}
	
	public void keyTyped(KeyEvent e) {
		
	}
	
	public char[] getNome() {
		return nome;
	}
	public void iniciarJogo() {
		janela.iniciarJogo();
	}
	public int getContador() {
		return contador;
	}
	
}
