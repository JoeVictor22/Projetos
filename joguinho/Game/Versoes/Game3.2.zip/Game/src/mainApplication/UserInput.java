package mainApplication;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class UserInput implements KeyListener{

	private Jogador jogador;
	private Canvas jogo;
	
	private boolean andandoDireita;
	private boolean andandoEsquerda;
	private boolean atacando;
	
	private Janela janela;
	

	
	

	
	public UserInput(Janela janela) {
		this.jogo = janela.getJogo();
		this.jogador = jogo.getJogador();
		this.andandoDireita = false;
		this.andandoEsquerda = false;
		this.atacando = false;
		jogo.setPausado(false);
		
		this.janela = janela;
		
		
	}
	
	public void verificar() {
		//return this.jogador;
	}
	
	//implementacao de keyListener
	
	
	public void keyPressed(KeyEvent e) {
		
		//jogo rodando
		if(!jogo.isPausado() && jogo.isJogando()) {
			
			//esquerda
			if(e.getKeyCode() == KeyEvent.VK_A) {
				if(andandoDireita == true) {
					jogador.andar(0);
				//	inimigo.andar(0);
				}else {
					jogador.andar(-1);
					//inimigo.andar(-1);
				}
				andandoEsquerda = true;
							
			}
			
			//direita
			if(e.getKeyCode() == KeyEvent.VK_D) {
				if(andandoEsquerda == true) {
					jogador.andar(0);
					//inimigo.andar(0);
				}else {
					jogador.andar(1);
				//	inimigo.andar(1);
				}
				andandoDireita = true;
			}
			
			//saltar
			if(e.getKeyCode() == KeyEvent.VK_W && !jogador.isAtacando()) {
				jogador.pular();
			}
			
			//bater
			if(e.getKeyCode() == KeyEvent.VK_F ) {
			
				if(!atacando) {
					
					jogador.atacar();
					//inimigo.atacar();
					jogador.setFimDeAtaque(true);
					atacando = true;
					
				}
			}
			
			//pausar
			if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				BGM.baixar(9.0f);
				jogo.setPausado(true);
			}
			
	
			
			
		//jogo pausado	
		}else {	
			if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				jogo.setPausado(false);
				jogador.andar(0);
				BGM.maximo();
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		if(!jogo.isPausado() && jogo.isJogando()) {
			if(e.getKeyCode() == KeyEvent.VK_A) {
				if(andandoDireita == true) {
					jogador.andar(1);
					//inimigo.andar(1);
					
				}else {
					jogador.andar(0);
					//inimigo.andar(0);
				}
				andandoEsquerda = false;
			}
			
			if(e.getKeyCode() == KeyEvent.VK_D) {
				if(andandoEsquerda == true) {
					jogador.andar(-1);
					//inimigo.andar(-1);
				}else {
					jogador.andar(0);
					//inimigo.andar(0);
				}
				andandoDireita = false;
			}
			
			if(e.getKeyCode() == KeyEvent.VK_F) {
				atacando = false;
			}
		}
	}
	
	public void keyTyped(KeyEvent e) {
		
	}
	
}
