package mainApplication;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * criar thread se necessario
 */


public class Arquivo {

	
	
	
	/*
	 * arquivo deve possuir seguinte formato
	 *  asd
		bsd
		csd
		dsd
		esd
		fsd
		gsd
		hsd
		isd
		jsd
		10
		9
		8
		7
		6
		5
		4
		3
		2
	    1
	 */
	
	
    public String[] ler(){
        String rank[] = new String[20];
      
        try{
            FileReader arquivo = new FileReader("Data/rank.txt");
            BufferedReader leitura = new BufferedReader(arquivo);
            String lendo;
            try{
                lendo = leitura.readLine();
                int linha = 0;
                while(linha < 20){
                    rank[linha] = lendo;
                    lendo = leitura.readLine();
                    linha++;
                }

                arquivo.close();
            }catch(IOException e){
            	e.printStackTrace();
                System.out.println("Deu erro 1");
                
            }
        }catch(FileNotFoundException e){
            System.out.println("Deu erro 2");
            e.printStackTrace();
        }
        
        
        return rank;
    }
    
    public void escrever(String[] rank) throws IOException{
        FileWriter arquivo = new FileWriter("Data/rank.txt");
        PrintWriter gravar = new PrintWriter(arquivo);
        for(int i = 0 ; i < 20; i++){
          
            gravar.printf(rank[i] + "\n");
        }
        arquivo.close();
    }
    
    
    
}
