package mainApplication;

public class Ranking {

}
