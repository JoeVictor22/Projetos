package mainApplication;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Overlay {

	private int altura = 50;
	private int largura = 50;
	
	private int h;
	private int w;
	
	private BufferedImage[] letras;
	private BufferedImage[] overlay;
	private int posXLetras;
	private int posYLetras;
	private int espacamento;
	
	private int imagemAtual;
	private int timer;
	private int velocidadeDasAnimacoes;
	private int quantidadeDeFrames;
	
	public Overlay(int h, int w){
		this.h = h;
		this.w = w;
		this.imagemAtual= 1;
		this.timer = 1;
		this.velocidadeDasAnimacoes = 120;
		this.quantidadeDeFrames = 5;
		
		letras = carregarImagens("Data/Sprites/Alfabeto/",11,"png");
		for(int i = 0; i < letras.length; i++) {
			letras[i] = resize(letras[i], 30, 30);
		}
		overlay = new BufferedImage[8];
		overlay = carregarImagens("Data/Extra/",7,"png");
		overlay[0] = resize(overlay[0], h,w);
		
		for(int i = 1; i < 4;i++) {
			overlay[i] = resize(overlay[1], 20*6 + 20*i, 20 + 5*i);
			overlay[3+i] = resize(overlay[1], 20*6 + 20*(3-i), 20 + 5*(3-i));
		}
		
		
		letras[10] = resize(letras[10], 30*5, 30);
		posXLetras = 1200;
		posYLetras = 40;
		espacamento = 30;
	}
	
	
	public void pintarPause(Graphics2D g) {
		g.drawImage(overlay[0], null, 0,0);
		g.drawImage(overlay[imagemAtual],null,h/2 - 30*3,w/2 - 30);
		if(timer >= velocidadeDasAnimacoes){
			imagemAtual++;
			if(imagemAtual == quantidadeDeFrames){
				imagemAtual = 1;
			}
			timer = 1;
		}
		timer++;
	}
	
	
	public void pintarVida(Graphics2D g, int vida) {
		
		
		
		for(int i = 0; i < vida ; i++) {
			g.setColor(Color.red);
			g.fillRect(40+ (largura+1)*i,40,largura,altura);
		}
	}
	
	public void pintarScore(Graphics2D g, long score) {
		
		/*
		 * TO DO
		 * Printar palavra score
		 */
		
		//converte o score para string
		String pontuacao = Long.toString(score);
		//System.out.println("long ta : " + score + " ja a string ta : " + pontuacao);
		
		/*
		 * contador j define o espacamento
		 * contador i comeca do ultimo caractere
		 */
		g.drawImage(letras[10], null, posXLetras - 150, posYLetras - 35);
		for(int j = 0, i = pontuacao.length()-1; i >= 0; i--, j++) {
			//System.out.println("A posicao eh " + (pontuacao.charAt(i) - '0'));
			g.drawImage(letras[pontuacao.charAt(i) - '0'], null, posXLetras - espacamento*j, posYLetras);
		}
		
	}
	
	
	
	public BufferedImage[] carregarImagens(String endereco, int size,  String extensao) {
		BufferedImage[] imagem = new BufferedImage[size];
		
		for(int i = 0; i < size; i++) {	
			try {
				imagem[i] = ImageIO.read(new File(endereco + i + "." + extensao));
			}catch(IOException e) {
				System.out.println("Metodo carregarImagens : nao carregou imagens "+ endereco+i+"." + extensao);
			}
			
		}
		return imagem;
	}
	
	public static BufferedImage resize(BufferedImage img, int W, int H) { 
		
	    Image temp = img.getScaledInstance(W, H, Image.SCALE_SMOOTH);
	    BufferedImage novaImagem = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = novaImagem.createGraphics();
	    g2d.drawImage(temp, 0, 0, null);
	    g2d.dispose();

	    return novaImagem;
	}  
	
}
